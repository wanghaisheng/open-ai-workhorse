﻿# oh-my-codex (OMX) 深度审视报告

## 项目真实面貌

版本 v0.16.3，28K stars，核心贡献者 1 人（87.5% commits），仅 3 个运行时依赖。

## 代码规模与 God Files

- src/cli/index.ts: 141KB/4458 行 (严重 God File)
- src/team/api-interop.ts: 55.2KB (严重 God File)
- src/hooks/keyword-detector.ts: 45.6KB (严重 God File)
- src/config/generator.ts: 55.3KB (部分合理)

## 好的设计（值得学习）

1. Agent 三维分类：posture (orchestrator/worker/scout) + modelClass (frontier/standard/fast) + routingRole (leader/specialist/executor)
2. 严格的阶段状态机：plan->prd->exec->verify->fix(循环)->complete/failed
3. 真正的 DAG + 环检测（DFS 三色标记法）
4. 可解释任务分配（每个决策生成 reason 字段）
5. 原子写入 + 写锁（tmp+rename + per-file Promise queue）
6. Commit Hygiene（运行时 commit vs 语义 commit 分离）
7. MCP state/memory/trace 分离架构
8. 进程生命周期管理（看门狗 + 优雅关闭）

## 严重问题

1. 编排器名不副实（orchestrator.ts 只有 163 行状态机定义）
2. 与 Codex CLI 深度耦合（仅 20-30% 代码可复用）
3. 单人项目风险（3 个月积累 3 个 50KB+ God File）
4. tmux 硬依赖（非 CLI 环境无法使用）

## 对 RAMS 的参考价值

概念参考权重：30%
强烈推荐：Posture 分类、状态机、DAG、可解释分配、MCP 架构、生命周期管理
不建议模仿：God File、编排器=状态机、tmux 依赖、Codex 耦合

> OMX 是好的设计模式参考书，但不是好的代码参考实现。
