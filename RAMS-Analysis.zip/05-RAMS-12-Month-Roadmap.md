﻿# RAMS Design Team 鈥?Role-Skill 鍔犺浇鏈哄埗涓庣珵鍝佸垎鏋?
> 鍩轰簬 `open-design-rams` 鐜版湁 `.claude/roles/` + `.claude/skills/` 鍒嗘瀽锛屽弬鑰?oh-my-agent 鏋舵瀯锛岃璁?RAMS 鐨?Role 榛樿 Skill 鍔犺浇鏈哄埗銆丩ocal Marketplace 妯″紡鍙婄珵鍝佸樊寮傚寲绛栫暐銆?
---

## 涓€銆佺幇鏈夎祫浜х洏鐐?
### 1.1 Role 娓呭崟锛?6 涓級

| 鍒嗙被 | Role | 鎻忚堪 | 鎶€鑳芥暟閲?|
|------|------|------|----------|
| **鏍稿績璁捐** | `design-lead` | 瑙嗚璁捐鎵ц涓撳 | 11 (P0:3, P1:3, P2:5) |
| | `design-builder` | 鍘熷瀷鍜屽疄鐜颁笓瀹?| 10 (P0:3, P1:3, P2:4) |
| | `design-critic` | 璁捐璇勫涓撳 | 8 (P0:4, P1:3, P2:1) |
| | `design-strategist` | 涓婃父璁捐鎬濈淮涓撳 | 8 (P0:3, P1:3, P2:2) |
| | `design-scout` | 绔炰簤UX鍒嗘瀽涓撳 | 5 (P0:2, P1:2, P2:1) |
| | `content-writer` | UX鍐欎綔涓撳 | 5 (P0:2, P1:2, P2:1) |
| | `inspiration-scout` | 缇庡鐏垫劅涓撳 | 3 (P0:2, P1:1, P2:0) |
| | `motion-designer` | 鍔ㄦ晥璁捐涓撳 | 3 (P0:2, P1:1, P2:0) |
| | `heuristic-evaluator` | 鍚彂寮忚瘎浼颁笓瀹?| 3 (P0:2, P1:1, P2:0) |
| **鏃犻殰纰嶄笓椤?* | `accessibility-reviewer` | 鏃犻殰纰嶈瘎瀹′笓瀹?| 30+ (鏈€涓板瘜) |
| | `inclusive-researcher` | 鍖呭鎬х爺绌跺憳 | 8 |
| | `adaptive-interface-specialist` | 鑷€傚簲鐣岄潰涓撳 | 10 |
| | `cognitive-accessibility-specialist` | 璁ょ煡鏃犻殰纰嶄笓瀹?| 10 |
| **AI 涓撻」** | `agent-orchestrator` | 鏅鸿兘浣撶紪鎺掕€?| 7 |
| | `ai-personality-designer` | AI涓€ц璁″笀 | 7 |
| | `model-evaluation-specialist` | 妯″瀷璇勪及涓撳 | 7 |

### 1.2 Skill 璧勪骇锛? 涓鍚?Skill锛?
褰撳墠浠?`.claude/skills/designer-role/` 涓€涓?Skill 鐩綍锛屼絾鍏跺唴閮ㄥ寘鍚?**30+ 瀛愭妧鑳芥ā鍧?*锛岃鐩?9 澶ц亴璐ｉ鍩燂細璁捐鐮旂┒銆乁X绛栫暐銆乁I璁捐銆佷氦浜掕璁°€佽璁＄郴缁熴€佸師鍨嬩笌娴嬭瘯銆佽璁¤繍钀ャ€佸績鐞嗗涓庤璁°€佹父鎴忚璁°€?
### 1.3 鐜版湁鏋舵瀯闂

| 闂 | 鎻忚堪 |
|------|------|
| **Role 鍐呭祵 Skill** | 褰撳墠 Skill 浠ュ瓧绗︿覆 ID 褰㈠紡鍐欏湪 Role 鐨?`role.md` 涓紝娌℃湁鐙珛鐨?Skill 瀹氫箟鏂囦欢 |
| **Skill 鏃犵嫭绔嬪畾涔?* | 30+ 瀛愭妧鑳芥暎钀藉湪 `designer-role/skills/` 涓嬶紝娌℃湁缁撴瀯鍖栧厓鏁版嵁锛堣瘎鍒嗐€侀€傜敤浠诲姟绫诲瀷銆佷緷璧栧叧绯伙級 |
| **鏃犲姞杞戒紭鍏堢骇鏈哄埗** | `config.yaml` 鍙湁 `auto_load: true`锛屾病鏈夊尯鍒?default/custom/marketplace |
| **鏃犺瘎鍒嗙郴缁?* | 娌℃湁 Skill 鏁堟灉璇勪及鍜岀敤鎴峰弽棣堟満鍒?|
| **IDE 缁戝畾** | 褰撳墠璺緞 `.claude/roles` 纭粦瀹?Claude IDE |

---

## 浜屻€乷h-my-agent 鍙傝€冩灦鏋勫垎鏋?
### 2.1 鏍稿績璁捐妯″紡

oh-my-agent 閲囩敤 **Agent-Skill 涓ゅ眰鍒嗙** 鏋舵瀯锛?
```
.agents/                    鈫?SSOT锛堝敮涓€鏁版嵁婧愶級
鈹溾攢鈹€ oma-config.yaml         鈫?鍏ㄥ眬閰嶇疆 + per-agent 瑕嗙洊
鈹溾攢鈹€ agents/                 鈫?Agent 瀹氫箟锛堣交閲?prompt锛?鈹?  鈹溾攢鈹€ frontend-engineer.md
鈹?  鈹斺攢鈹€ variants/           鈫?澶?IDE 閫傞厤
鈹溾攢鈹€ skills/                 鈫?Skill 瀹氫箟锛堟繁搴︾煡璇嗗簱锛?鈹?  鈹溾攢鈹€ _shared/            鈫?鍏变韩鍗忚灞?鈹?  鈹溾攢鈹€ oma-frontend/
鈹?  鈹?  鈹溾攢鈹€ SKILL.md        鈫?SSL-lite 缁撴瀯鍖栨弿杩?鈹?  鈹?  鈹斺攢鈹€ resources/
鈹?  鈹斺攢鈹€ oma-orchestrator/
鈹溾攢鈹€ config/defaults.yaml    鈫?Agent-Skill 鏄犲皠
鈹溾攢鈹€ workflows/              鈫?宸ヤ綔娴佸畾涔?鈹溾攢鈹€ hooks/                  鈫?鍏抽敭璇嶈嚜鍔ㄦ娴?鈹斺攢鈹€ rules/                  鈫?棰嗗煙瑙勫垯
```

### 2.2 Agent-Skill 缁戝畾鏂瑰紡

姣忎釜 Agent 榛樿缁戝畾 **1 涓悓鍚?Skill**锛堜竴瀵逛竴鏄犲皠锛夛紝Skill 鍐呴儴閫氳繃 SSL-lite 缁撴瀯瀹氫箟瀹屾暣鐨勮皟搴︺€佹祦绋嬨€侀€昏緫銆?
### 2.3 鐢ㄦ埛鑷畾涔夋満鍒?
| 灞傜骇 | 鏈哄埗 | 绀轰緥 |
|------|------|------|
| **棰勮閫夋嫨** | 瀹夎鏃堕€夋嫨 preset | `Fullstack` / `Frontend` / `Backend` |
| **Per-agent 瑕嗙洊** | oma-config.yaml | `agents.backend.model: openai/gpt-5.5` |
| **鑷畾涔夐璁?* | extends + 瑕嗙洊 | `custom_presets.my-team.extends: claude-only` |
| **Variant 绯荤粺** | 澶?IDE 閫傞厤 | `oma link` 鐢熸垚 `.claude/agents/*.md` |

### 2.4 oh-my-agent 鐨勫眬闄愶紙RAMS 鐨勬満浼氾級

| 灞€闄?| RAMS 鐨勫樊寮傚寲鏂瑰悜 |
|------|-------------------|
| Agent-Skill **涓€瀵逛竴缁戝畾** | RAMS 鏀寔 **N:M 澶氬澶?* |
| 鏃?Skill 璇勫垎绯荤粺 | RAMS 鐨?**task-driven scoring** |
| 鏃?Marketplace锛堜粎 APM 鍖呭畨瑁咃級 | RAMS 鐨?**dual Marketplace** |
| Skill 鏃犻€傜敤浠诲姟绫诲瀷鏍囨敞 | RAMS 鐨?**skillId 脳 taskType** 鐭╅樀 |
| 鏃犺法鐢ㄦ埛缁忛獙鑱氬悎 | RAMS 鐨?**Marketplace 鑱氬悎璇勫垎** |

---

## 涓夈€丷AMS Role-Skill 鍔犺浇鏈哄埗璁捐

### 3.1 涓夊眰鍔犺浇浼樺厛绾?
```
鈹屸攢鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹?鈹? Layer 3: Marketplace Skills锛堣繙绋嬪競鍦猴級          鈹? 鈫?鏈€楂樹紭鍏堢骇
鈹? 鐢ㄦ埛浠?Marketplace 瀹夎/璁㈤槄鐨?Skill             鈹?鈹溾攢鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹?鈹? Layer 2: User Custom Skills锛堢敤鎴疯嚜瀹氫箟锛?       鈹?鈹? 鐢ㄦ埛鍦ㄩ」鐩腑鑷鍒涘缓/淇敼鐨?Skill                鈹?鈹溾攢鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹?鈹? Layer 1: Default Skills锛堥粯璁ゅ姞杞斤級              鈹? 鈫?鍩虹嚎
鈹? Role 瀹氫箟涓０鏄庣殑榛樿 Skill 鏍?                  鈹?鈹斺攢鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹?
鍚堝苟绛栫暐锛欻igher layer 鐨?Skill 鍚屽悕鏃惰鐩?Lower layer
```

### 3.2 鐩綍缁撴瀯锛堝熀浜庣幇鏈?`.claude/` 閲嶆瀯锛?
```
.open-design/                          鈫?SSOT
鈹溾攢鈹€ config.yaml
鈹溾攢鈹€ roles/
鈹?  鈹溾攢鈹€ design-lead/
鈹?  鈹?  鈹溾攢鈹€ role.yaml                  鈫?Role 鍏冩暟鎹?鈹?  鈹?  鈹溾攢鈹€ soul.md                    鈫?瑙掕壊浜烘牸
鈹?  鈹?  鈹溾攢鈹€ default-skills.yaml        鈫?鈽?榛樿 Skill 鏍?鈹?  鈹?  鈹溾攢鈹€ actors/                    鈫?Actor 閫傞厤
鈹?  鈹?  鈹斺攢鈹€ variants/
鈹?  鈹斺攢鈹€ ...
鈹溾攢鈹€ skills/                            鈫?Skill 瀹氫箟锛堢嫭绔嬩簬 Role锛?鈹?  鈹溾攢鈹€ core/                          鈫?鏍稿績 Skill
鈹?  鈹?  鈹溾攢鈹€ token-architecture/
鈹?  鈹?  鈹?  鈹溾攢鈹€ skill.yaml             鈫?鍏冩暟鎹?+ 璇勫垎
鈹?  鈹?  鈹?  鈹溾攢鈹€ prompt.md
鈹?  鈹?  鈹?  鈹斺攢鈹€ resources/
鈹?  鈹?  鈹斺攢鈹€ ...
鈹?  鈹溾攢鈹€ accessibility/
鈹?  鈹溾攢鈹€ ai/
鈹?  鈹斺攢鈹€ _shared/                       鈫?鍏变韩鍗忚
鈹溾攢鈹€ custom-skills/                     鈫?Layer 2: 鐢ㄦ埛鑷畾涔?鈹溾攢鈹€ marketplace/installed/             鈫?Layer 3: Marketplace 缂撳瓨
鈹溾攢鈹€ scores/                            鈫?Local 璇勫垎鏁版嵁搴?鈹斺攢鈹€ adapters/                          鈫?IDE 閫傞厤灞?```

### 3.3 Default Skills 澹版槑鏍煎紡

```yaml
# .open-design/roles/design-lead/default-skills.yaml
version: "1.0"
role: design-lead

default_skills:
  # P0 鈥?鏍稿績蹇呭锛堝缁堝姞杞斤級
  - skill_id: token-architecture
    priority: P0
    required: true
    reason: "璁捐浠ょ墝鏋舵瀯鏄瑙夎璁＄殑鍩虹煶"

  - skill_id: design-system-alignment
    priority: P0
    required: true

  - skill_id: ui-composition
    priority: P0
    required: true

  # P1 鈥?鎺ㄨ崘鍔犺浇锛堥粯璁ゅ惎鐢紝鐢ㄦ埛鍙叧闂級
  - skill_id: design-state
    priority: P1
    required: false
    default_enabled: true

  # P2 鈥?鍙€夊姞杞斤紙榛樿鍏抽棴锛岀敤鎴锋寜闇€寮€鍚級
  - skill_id: design-taste
    priority: P2
    required: false
    default_enabled: false
```

### 3.4 Skill 鍏冩暟鎹牸寮?
```yaml
# .open-design/skills/core/token-architecture/skill.yaml
id: token-architecture
name: 璁捐浠ょ墝鏋舵瀯
version: "1.0.0"
description: 瀹氫箟鍜岀鐞嗚璁′护鐗岀殑绯荤粺鍖栨柟娉?
task_types:
  - design-system: { weight: 0.95 }
  - visual-design: { weight: 0.85 }
  - prototype: { weight: 0.60 }

default_score: 7.5
dependencies: []
tags: [璁捐绯荤粺, 浠ょ墝, 棰滆壊, 鎺掔増, 闂磋窛]
```

### 3.5 鐢ㄦ埛鑷畾涔?Skill锛堢户鎵?+ 瑕嗙洊锛?
```yaml
# .open-design/custom-skills/my-brand-color-system/skill.yaml
id: my-brand-color-system
name: 鍝佺墝鑹插僵绯荤粺
extends: token-architecture           # 缁ф壙鍩虹 Skill
overrides:
  - resource: prompt.md
    with: custom-brand-prompt.md
```

### 3.6 CLI 浜や簰绀轰緥

```bash
rams role:skills design-lead

# 杈撳嚭锛?# design-lead Skill Stack:
# 鈹屸攢鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹攢鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹攢鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹攢鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹?# 鈹?Skill                    鈹?Source  鈹?Priority 鈹?Score  鈹?# 鈹溾攢鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹尖攢鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹尖攢鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹尖攢鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹?# 鈹?token-architecture       鈹?default 鈹?P0       鈹?7.5    鈹?# 鈹?design-system-alignment  鈹?default 鈹?P0       鈹?7.5    鈹?# 鈹?dark-mode-system         鈹?market  鈹?P1 鉁?    鈹?9.1 鈽? 鈹?# 鈹?design-taste             鈹?default 鈹?P2       鈹?--     鈹?# 鈹斺攢鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹粹攢鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹粹攢鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹粹攢鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹?
rams skill:install community/dark-mode-system --role design-lead
rams skill:create my-brand-colors --extends token-architecture
```

---

## 鍥涖€佺幇鏈?Role 鈫?RAMS Skill 鏄犲皠锛堝叧閿鑹诧級

### design-lead锛堣璁¤礋璐ｄ汉锛?
| 浼樺厛绾?| Skill ID | 閫傜敤浠诲姟绫诲瀷 |
|--------|----------|-------------|
| P0 | `token-architecture` | design-system, visual-design |
| P0 | `design-system-alignment` | design-system, review |
| P0 | `ui-composition` | visual-design, prototype |
| P1 | `design-state` | all |
| P1 | `responsive-patterns` | visual-design, prototype |
| P1 | `interaction-design` | interaction, prototype |
| P2 | `design-taste` | review |
| P2 | `adaptive-interfaces` | accessibility |

### accessibility-reviewer锛堟棤闅滅璇勫鑰咃級鈥?鎶€鑳芥渶涓板瘜

| 鍒嗙被 | Skills | 浼樺厛绾?|
|------|--------|--------|
| 鍐呭鏃犻殰纰?| `alt-text-design`, `form-labelling`, `heading-structure`, `link-text-design`, `readable-content`, `table-accessibility`, `multimedia-accessibility` | P0 |
| 浜や簰鏃犻殰纰?| `keyboard-navigation`, `touch-target-design`, `multi-modal-input`, `gesture-alternatives`, `voice-interaction`, `motion-sensitivity`, `feedback-and-status` | P0 |
| 鏃犻殰纰嶇瓥鐣?| `accessibility-testing-strategy`, `accessibility-debt-tracking`, `compliance-mapping`, `tradeoff-analysis` | P1 |

> **鍏抽敭娲炲療**锛歛ccessibility-reviewer 鐨?30+ 涓?Skill 搴旇琚媶鍒嗕负鐙珛鍙鐢ㄦā鍧楋紝design-lead銆乨esign-builder 绛夎鑹蹭篃鍙互鎸夐渶鍔犺浇鍏朵腑閮ㄥ垎 Skill銆?
### agent-orchestrator锛堟櫤鑳戒綋缂栨帓鑰咃級

| 浼樺厛绾?| Skill ID |
|--------|----------|
| P0 | `agent-role-design`, `handoff-protocols`, `human-in-the-loop`, `failure-recovery`, `observability-design`, `state-management`, `task-decomposition` |

---

## 浜斻€丩ocal Marketplace 妯″紡

### 5.1 璇勫垎鏁版嵁缁撴瀯

```typescript
interface SkillScoreDB {
  [skillId: string]: {
    totalUses: number
    averageScore: number
    scoresByTaskType: {
      [taskType: string]: { count: number, avg: number, scores: number[] }
    }
  }
}
```

### 5.2 璇勫垎鍏紡

```
缁煎悎璇勫垎 = 鑷姩璇勪及鍒?脳 0.6 + 鐢ㄦ埛鍙嶉鍒?脳 0.4
锛堟棤鍙嶉鏃讹細缁煎悎璇勫垎 = 鑷姩璇勪及鍒?脳 0.8 + 榛樿鍩虹嚎鍒?7.0) 脳 0.2锛?```

### 5.3 璇勫垎鏌ヨ浼樺厛绾?
```typescript
function getSkillScore(skillId, taskType) {
  // 1. 涓汉 + 鐗瑰畾浠诲姟绫诲瀷锛堚墺2娆′娇鐢級
  // 2. 涓汉鏁翠綋璇勫垎锛堚墺1娆′娇鐢級
  // 3. Skill 榛樿璇勫垎锛?.0锛?}
```

### 5.4 Local 鈫?Marketplace 鍗囩骇璺緞

```
Local 妯″紡                    Marketplace 妯″紡
鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€                    鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€
涓汉璇勫垎 (浠呰嚜宸?     鈹€鈹€鈫?   鑱氬悎璇勫垎 (鎵€鏈夌敤鎴?
~/.rams/scores/       鈹€鈹€鈫?   Marketplace API
鎵嬪姩閫夋嫨 Skill        鈹€鈹€鈫?   璇勫垎鎺ㄨ崘 + 鎼滅储
```

**鍏抽敭鍘熷垯**锛氭暟鎹粨鏋勫拰 API 瀹屽叏涓€鑷达紝鍗囩骇鍙渶鍒囨崲鏁版嵁婧愩€?
---

## 鍏€佺珵鍝佸樊寮傚寲瀵规瘮

### 6.1 浜旂淮瀵规瘮鐭╅樀

| 缁村害 | oh-my-agent | agent-skills | Hermes | claw-code | **RAMS** |
|------|-------------|--------------|--------|-----------|----------|
| **瀹氫綅** | 澶欰gent妗嗘灦 | Skill鍚堥泦 | 閫氱敤鍔╂墜 | Code杩愯鏃?| **鍥㈤槦缂栨帓** |
| **Role-Skill** | 1:1 | 鏃燫ole | 鏃燫ole | 鏃?| **N:M** |
| **Skill璇勫垎** | 鉂?| 猸恠tars | 鉂?| 鉂?| **鉁卼ask-driven** |
| **Marketplace** | APM | GitHub | 鉂?| 鉂?| **鉁卍ual** |
| **棰嗗煙涓撶簿** | 杞欢宸ョ▼ | 閫氱敤 | 閫氱敤 | 缂栫爜 | **璁捐+鍙墿灞?* |
| **鐢熸€侀杞?* | 鉂?| 猸愮ぞ鍖?| 鉂?| 鉂?| **鉁呰瘎鍒嗏啋鎺ㄨ崘鈫掕川閲?* |

### 6.2 RAMS 鐢熸€侀杞?
```
鐢ㄦ埛浠诲姟 鈫?Skill浣跨敤 鈫?璇勫垎绉疮 鈫?鏅鸿兘鎺ㄨ崘 鈫?璐ㄩ噺鎻愬崌 鈫?鏇村鐢ㄦ埛
    鈫?                                             鈹?    鈹斺攢鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹?```

---

## 涓冦€佸疄鏂借矾绾垮浘

### Phase 1: 鍩虹閲嶆瀯锛圠ocal 妯″紡锛?1. `.claude/` 鈫?`.open-design/` 杩佺Щ
2. Skill 浠?Role 鎷嗗垎涓虹嫭绔嬫ā鍧?3. 3 灞傚姞杞芥満鍒跺疄鐜?4. Local 璇勫垎绯荤粺

### Phase 2: 閫傞厤灞?5. `adapters/claude/`, `adapters/windsurf/`, `adapters/cursor/`
6. `rams link --target <ide>` CLI

### Phase 3: Marketplace
7. Skill Marketplace MVP锛堝彂甯?鎼滅储/瀹夎/鑱氬悎璇勫垎锛?8. Role Marketplace锛堝熀浜庤瘎鍒嗚嚜鍔ㄧ粍鍚?+ 妯℃澘鍒嗕韩锛?
---

## 鍏€佹牳蹇冭璁″喅绛栨€荤粨

1. **Skill 浠?Role 涓В鑰?*锛?00+ Skill ID 鍏ㄩ儴鎷嗗垎涓虹嫭绔嬫ā鍧楋紝鏀寔璺?Role 澶嶇敤
2. **3 灞傚姞杞戒紭鍏堢骇**锛欴efault 鈫?Custom 鈫?Marketplace锛岀敤鎴峰缁堟嫢鏈夋渶缁堟帶鍒舵潈
3. **task-driven 璇勫垎**锛氬悓涓€ Skill 鍦ㄤ笉鍚屼换鍔＄被鍨嬩腑鐙珛璇勫垎
4. **Local 浼樺厛**锛氳瘎鍒嗙郴缁熷湪 Local 妯″紡涓嬪畬鏁村彲鐢紝Marketplace 涓婄嚎鍚庢棤缂濆崌绾?5. **鍙傝€冧絾涓嶅鍒?oh-my-agent**锛氬€熼壌 SSOT + 涓ゅ眰鍒嗙 + Variant 閫傞厤锛屼絾鍔犲叆璇勫垎绯荤粺鍜?Marketplace 鐢熸€?'@ | Set-Content -Path "$dir\01-RAMS-Role-Skill-Loading-Analysis.md" -Encoding UTF8

# File 2: Competitive Analysis IDE CLI
@'
# AI 缂栫爜宸ュ叿鍙墿灞曟€у姣旀姤鍛婏紙2026骞?鏈堬級

## 璇勪及鑳屾櫙

鏈姤鍛婇拡瀵逛簲澶т富娴?AI 缂栫爜宸ュ叿锛屼粠**澶氭櫤鑳戒綋缂栨帓妗嗘灦锛堝 RAMS锛夊熀纭€骞冲彴**鐨勮瑙掕繘琛屽彲鎵╁睍鎬ф繁搴﹀姣斻€?
---

## 涓€銆侀€愬伐鍏疯缁嗗垎鏋?
### 1. Claude Code CLI锛圓nthropic锛?
| 缁村害 | 璇︽儏 |
|------|------|
| **鑷畾涔?Agent** | 鍘熺敓鏀寔銆傞€氳繃 `.claude/agents/` 鐩綍鏀剧疆 `.md` 鏂囦欢瀹氫箟瀛愪唬鐞?|
| **鎻掍欢/鎵╁睍** | Skills + MCP Server锛?00+锛? Hooks锛?6 涓敓鍛藉懆鏈?Hook锛?|
| **鍙紪绋嬭嚜鍔ㄥ寲** | Headless Mode + Agent SDK |
| **澶氭ā鍨嬫敮鎸?* | 鍘熺敓浠?Anthropic锛屽彲閫氳繃绗笁鏂硅矾鐢辨帴鍏?40+ 渚涘簲鍟?|
| **閰嶇疆鏍煎紡** | `CLAUDE.md` + `settings.json` + `.claude/agents/*.md` |
| **绀惧尯鐢熸€?* | MCP 鍗忚鍙戣捣鑰咃紝800+ 鏈嶅姟鍣紝41% 寮€鍙戣€呭競鍗犵巼 |
| **瀛?Agent 娲剧敓** | 鍘熺敓 Agent Teams 骞惰 |
| **MCP 鏀寔** | A+锛堝崗璁彂璧疯€咃級 |

### 2. Codex CLI锛圤penAI锛?
| 缁村害 | 璇︽儏 |
|------|------|
| **鑷畾涔?Agent** | `AGENTS.md` + `~/.agents/skills/` |
| **鎻掍欢/鎵╁睍** | Skills + MCP + Hooks + Remote Plugins |
| **鍙紪绋嬭嚜鍔ㄥ寲** | `codex exec` 闈炰氦浜掓ā寮?|
| **澶氭ā鍨嬫敮鎸?* | 鍘熺敓 OpenAI锛孊YOK 鏀寔绗笁鏂?|
| **閰嶇疆鏍煎紡** | `config.toml` + `codex.json` + `AGENTS.md` |
| **绀惧尯鐢熸€?* | 75k+ stars锛?70 涓囧懆涓嬭浇锛屽畬鍏ㄥ紑婧?Apache-2.0 |
| **瀛?Agent 娲剧敓** | 浜戠骞惰 + worktree |
| **MCP 鏀寔** | B+ |

### 3. Cursor锛圓nysphere锛?
| 缁村害 | 璇︽儏 |
|------|------|
| **鑷畾涔?Agent** | 8 Agent 骞惰锛圕ursor 2.0锛?|
| **鎻掍欢/鎵╁睍** | Cursor SDK锛?026.4.29 鍙戝竷锛? MCP |
| **鍙紪绋嬭嚜鍔ㄥ寲** | A+锛圕ursor SDK 鎻愪緵 Agent/Runtime/Model 涓夊眰鎶借薄锛?|
| **澶氭ā鍨嬫敮鎸?* | A锛堣嚜鐮?Composer + 澶氫緵搴斿晢锛?|
| **瀛?Agent 娲剧敓** | 8 Agent 骞惰锛岀嫭绔?worktree |
| **MCP 鏀寔** | A锛堝姩鎬佷笂涓嬫枃鍙戠幇锛孴oken 鏁堢巼鎻愬崌 46.9%锛?|

### 4. Windsurf锛圕odeium锛?
| 缁村害 | 璇︽儏 |
|------|------|
| **鑷畾涔?Agent** | Workflows + Global Rules |
| **鎻掍欢/鎵╁睍** | MCP锛堟帴鍏ヤ綋楠屾渶浣筹級+ Cascade |
| **鍙紪绋嬭嚜鍔ㄥ寲** | D锛堟棤 SDK锛?|
| **澶氭ā鍨嬫敮鎸?* | A锛?00+ 妯″瀷锛?|
| **瀛?Agent 娲剧敓** | C锛圕ascade 绾挎€ф祦锛?|

### 5. Gemini CLI锛圙oogle锛?
| 缁村害 | 璇︽儏 |
|------|------|
| **鑷畾涔?Agent** | 鏈夐檺锛堝唴缃笓鐢ㄥ瓙鏅鸿兘浣擄級 |
| **鎻掍欢/鎵╁睍** | Extensions 鍖呯鐞?+ MCP |
| **鍙紪绋嬭嚜鍔ㄥ寲** | D锛堟棤 SDK锛?|
| **澶氭ā鍨嬫敮鎸?* | D锛堝師鐢熶粎 Gemini锛?|
| **瀛?Agent 娲剧敓** | C- |

---

## 浜屻€佺患鍚堝姣旂煩闃?
| 璇勪及缁村害 | Claude Code | Codex CLI | Cursor | Windsurf | Gemini CLI |
|----------|:-----------:|:---------:|:------:|:--------:|:----------:|
| **鑷畾涔?Agent** | A | B+ | A- | C+ | C |
| **鎻掍欢/鎵╁睍** | A | B+ | A- | B | B |
| **鍙紪绋?鑷姩鍖?* | A | B+ | **A+** | D | D |
| **澶氭ā鍨嬫敮鎸?* | C | C | **A** | **A** | D |
| **閰嶇疆鎴愮啛搴?* | **A** | A- | B+ | B | B- |
| **绀惧尯鐢熸€?* | A- | **A+** | A | B+ | B |
| **瀛?Agent 娲剧敓** | **A** | B+ | **A** | C | C- |
| **MCP 鏀寔** | **A+** | B+ | A | A- | B+ |
| **寮€婧愮▼搴?* | C | **A** | D | D | **A** |
| **缁煎悎鍙墿灞曟€?* | **A** | **A-** | **A** | B+ | B- |

---

## 涓夈€丷AMS 閫夊瀷寤鸿

### 绗竴姊槦锛欳laude Code
- 鍞竴鍚屾椂鍏峰 Agent 瀹氫箟 + Skills + MCP + 瀛?Agent + SDK 鐨勫伐鍏?- 椋庨櫓锛氶棴婧愩€佷粎 Anthropic 妯″瀷

### 绗簩姊槦锛欳odex CLI
- 瀹屽叏寮€婧愩€佹渶澶хぞ鍖恒€乷h-my-codex 宸查獙璇佸 Agent 缂栨帓
- 椋庨櫓锛氱増鏈?0.x銆丄gent 瀹氫箟鑳藉姏涓嶅 Claude Code

### 绗笁姊槦锛欳ursor
- Cursor SDK 鏄?2026 骞存渶閲嶈鐨?Agent 鍩虹璁炬柦
- 椋庨櫓锛歋DK 鍒氬彂甯冦€侀棴婧?
### 鎺ㄨ崘锛欳odex 浼樺厛 + 澶氬悗绔€傞厤
RAMS Core 涓嶇粦瀹氫换浣曟墽琛屽紩鎿庯紝Codex Adapter 浣滀负绗竴浼樺厛瀹炵幇銆?'@ | Set-Content -Path "$dir\02-Competitive-Analysis-IDE-CLI.md" -Encoding UTF8

# File 3: oh-my-codex Deep Dive
@'
# oh-my-codex (OMX) 娣卞害瀹¤鎶ュ憡

## 涓€銆侀」鐩湡瀹為潰璨?
| 鎸囨爣 | 鏁板€?|
|------|------|
| 鐗堟湰 | v0.16.3锛?026-02-02 鍒涘缓锛屼粎 3 涓湀锛?|
| Stars | 28,055 |
| 鏍稿績璐＄尞鑰?| **1 浜?*锛圷eachan-Heo 鍗?87.5% commits锛?|
| 杩愯鏃朵緷璧?| **浠?3 涓?*锛坄@iarna/toml`, `@modelcontextprotocol/sdk`, `zod`锛?|
| 娴嬭瘯 | 255 涓敤渚嬶紝浣嗗瓨鍦ㄧ幆澧冩薄鏌撻棶棰?|

---

## 浜屻€佹灦鏋勭湡瀹炶川閲?
### 2.1 浠ｇ爜瑙勬ā涓?God Files

| 鏂囦欢 | 澶у皬 | 璇勭骇 |
|------|------|------|
| `src/cli/index.ts` | **141KB / 4458 琛?* | 馃敶 涓ラ噸 God File |
| `src/team/api-interop.ts` | **55.2KB** | 馃敶 涓ラ噸 God File |
| `src/hooks/keyword-detector.ts` | **45.6KB** | 馃敶 涓ラ噸 God File |
| `src/config/generator.ts` | **55.3KB** | 馃煛 鍔熻兘闆嗕腑浣嗛儴鍒嗗悎鐞?|

### 2.2 濂界殑璁捐锛堝€煎緱瀛︿範锛?
#### 鉁?Agent 涓夌淮鍒嗙被浣撶郴

```typescript
interface AgentDefinition {
  name: string;
  posture: 'frontier-orchestrator' | 'deep-worker' | 'fast-lane';
  modelClass: 'frontier' | 'standard' | 'fast';
  routingRole: 'leader' | 'specialist' | 'executor';
  reasoningEffort: 'low' | 'medium' | 'high';
  tools: 'read-only' | 'analysis' | 'execution' | 'data';
  category: 'build' | 'review' | 'domain' | 'product' | 'coordination';
}
```

#### 鉁?涓ユ牸鐨勯樁娈电姸鎬佹満

```
team-plan 鈫?team-prd 鈫?team-exec 鈫?team-verify 鈫?team-fix锛堝惊鐜洖 team-exec锛?                                         鈫?           鈫?                                     complete      failed锛堣秴杩?3 娆?fix锛?```

#### 鉁?鐪熸鐨?DAG + 鐜娴?浣跨敤 DFS 涓夎壊鏍囪娉曟娴嬫湁鍚戝浘涓殑鐜€?
#### 鉁?鍙В閲婄殑浠诲姟鍒嗛厤
姣忎釜鍒嗛厤鍐崇瓥閮界敓鎴愪汉绫诲彲璇荤殑 `reason` 瀛楁銆?
#### 鉁?鍘熷瓙鍐欏叆 + 鍐欓攣
tmp + rename 鍘熷瓙鎿嶄綔 + per-file Promise queue 涓茶鍖栥€?
#### 鉁?Commit Hygiene 鎬濇兂
鍖哄垎杩愯鏃惰剼鎵嬫灦 commit 鍜屾渶缁堣涔?commit銆?
### 2.3 涓ラ噸闂

#### 馃敶 缂栨帓鍣ㄥ悕涓嶅壇瀹?`orchestrator.ts` 鍙湁 163 琛岋紝鍙槸鐘舵€佹満瀹氫箟銆傜湡姝ｇ殑骞惰鎵ц閫昏緫鏁ｈ惤鍦?4458 琛岀殑 CLI 鍏ュ彛涓€?
#### 馃敶 涓?Codex CLI 娣卞害鑰﹀悎
浼拌鍙湁 20-30% 鐨勪唬鐮佸彲浠ヨ劚绂?Codex 鐙珛澶嶇敤銆?
#### 馃敶 鍗曚汉椤圭洰椋庨櫓
28K stars 鈮?鐢熶骇绾хǔ瀹氭€с€? 涓湀绉疮鍑?3 涓?50KB+ God File銆?
---

## 涓夈€丼kill 绯荤粺鍒嗘瀽

### 3.1 SKILL.md 缁熶竴鏍煎紡

鎵€鏈?Skill 閬靛惊楂樺害涓€鑷寸殑澹版槑寮忕粨鏋勶細YAML frontmatter + XML 鏍囩锛圥urpose/Use_When/Steps/State_Management/Checklist锛夈€?
### 3.2 Skill 灞傜骇鍏崇郴

```
autopilot锛堝叏鑷不绠＄嚎锛?  鈹斺攢鈹€ ralph锛堟寔涔呭寲 + 楠岃瘉瀹屾垚锛?        鈹斺攢鈹€ ultrawork锛堝苟琛屾墽琛?+ 杞婚噺璇佹嵁锛?team锛坱mux 骞惰鍗忚皟锛夆€?鐙珛
deep-interview锛堥渶姹傛緞娓咃級鈥?瑙勫垝鍓?```

### 3.3 Catalog 鐢熷懡鍛ㄦ湡

| 鐘舵€?| 鏁伴噺 |
|------|------|
| active | 27 |
| deprecated | 10 |
| alias | 3 |
| merged | 3 |

瓒嬪娍锛氬ぇ閲?reviewer 琚悎骞朵负 code-reviewer锛岀郴缁熷湪鎸佺画鏀舵暃銆?
---

## 鍥涖€佸 RAMS 鐨勫弬鑰冧环鍊?
### 姒傚康鍙傝€冩潈閲嶏細30%

**寮虹儓鎺ㄨ崘鍊熼壌**锛?1. Posture 涓夌淮鍒嗙被锛堟帶鍒?Agent 鍐崇瓥椋庢牸锛?2. 闃舵鐘舵€佹満 + 杞崲淇濇姢
3. DAG + 鐜娴?4. 鍙В閲婂垎閰嶏紙reason 瀛楁锛?5. MCP state/memory/trace 鍒嗙鏋舵瀯
6. 杩涚▼鐢熷懡鍛ㄦ湡绠＄悊锛堢湅闂ㄧ嫍 + 浼橀泤鍏抽棴锛?
**涓嶅缓璁ā浠?*锛?1. God File锛?458 琛?CLI 鍏ュ彛锛?2. 缂栨帓鍣?= 鐘舵€佹満锛堝悕涓嶅壇瀹烇級
3. tmux 纭緷璧?4. Codex CLI 娣卞害鑰﹀悎
5. 50KB 鍏抽敭璇嶆娴嬫枃浠?
### 涓€鍙ヨ瘽鎬荤粨

> OMX 鏄竴鏈ソ鐨?璁捐妯″紡鍙傝€冧功"锛屼絾涓嶆槸濂界殑"浠ｇ爜鍙傝€冨疄鐜?銆傚€熼壌鐘舵€佹満銆丏AG銆丳osture 鍒嗙被绛夎璁℃€濇兂锛屼笉瑕佸鍒朵唬鐮佺粍缁囨柟寮忋€?'@ | Set-Content -Path "$dir\03-oh-my-codex-Deep-Dive.md" -Encoding UTF8

# File 4: Competitor Reference Classification
@'
# 绔炲搧鎸?瀹氫箟鍙傝€?鍜?鎵ц鍙傝€?浜岀淮鍒嗙被

## 鍏ㄦ櫙鍥?
| Repo | Stars | Role/Skill 瀹氫箟 | 鎵ц Runtime/LLM 缁戝畾 |
|------|-------|:-:|:-:|
| **oh-my-agent** | 919 | 猸愨瓙猸?| 猸?|
| **oh-my-codex** | 28k | 猸愨瓙猸?| 猸愨瓙猸?|
| **agent-skills** | 33k | 猸愨瓙 | 鈥?|
| **system-prompts** | 82k | 猸?| 鈥?|
| **Hermes Agent** | 138k | 猸?| 猸愨瓙 |
| **OpenClaw** | 369k | 猸?| 猸愨瓙猸?|
| **claw-code** | 189k | 鈥?| 猸愨瓙猸?|
| **Codex CLI** | 158k | 猸?| 猸愨瓙猸?|
| **Claude Code** | 闂簮 | 猸愨瓙 | 猸愨瓙猸?|

---

## 缁村害涓€锛歊ole/Skill 瀹氫箟鍙傝€?
### 馃 oh-my-agent锛堟渶寮猴級

| 璁捐鐐?| RAMS 鍙€熼壌 |
|--------|:-:|
| SSOT 妯″紡锛坄.agents/` 鍞竴鏁版嵁婧愶級 | 鉁?鐩存帴閲囩敤 |
| Agent-Skill 涓ゅ眰鍒嗙 | 鉁?鐩存帴閲囩敤 |
| SKILL.md / SSL-lite 鏍煎紡 | 鉁?鍙傝€冩牸寮?|
| Catalog 鐢熷懡鍛ㄦ湡绠＄悊 | 鉁?鐩存帴閲囩敤 |
| Per-agent 妯″瀷瑕嗙洊 | 鉁?鐩存帴閲囩敤 |
| Variant 绯荤粺锛堝 IDE 閫傞厤锛?| 鉁?鐩存帴閲囩敤 |
| _shared/ 鍏变韩鍗忚灞?| 鉁?鐩存帴閲囩敤 |
| Agent-Skill 1:1 缁戝畾 | 鉂?RAMS 闇€瑕?N:M |

### 馃 oh-my-codex

| 璁捐鐐?| RAMS 鍙€熼壌 |
|--------|:-:|
| Posture 缁村害锛坥rchestrator/worker/scout锛?| 鉁?寮虹儓鎺ㄨ崘 |
| ModelClass 缁村害锛坒rontier/standard/fast锛?| 鉁?鐩存帴閲囩敤 |
| RoutingRole 缁村害锛坙eader/specialist/executor锛?| 鉁?鐩存帴閲囩敤 |
| Posture Overlay锛堟敞鍏ヨ涓烘寚浠わ級 | 鉁?寮虹儓鎺ㄨ崘 |
| Catalog 鏀舵暃瓒嬪娍 | 鉁?鍙傝€?|

### 馃 agent-skills

浠呭弬鑰冨師瀛?Skill 绮掑害鍜屾寜鍔熻兘棰嗗煙鍒嗙被銆傚お绠€鍗曪紝鍙傝€冧环鍊兼湁闄愩€?
### 涓嶅缓璁弬鑰冨畾涔夌殑

system-prompts锛堝彧鏄?prompt 鏂囨湰浠撳簱锛夈€丠ermes锛堟棤 Role/Skill 姒傚康锛夈€丱penClaw锛圧ole 瀹氫箟鍦ㄦ彃浠朵腑鑰岄潪鏍稿績锛夈€乧law-code锛堝叧娉ㄦ墽琛屽眰锛夈€?
---

## 缁村害浜岋細Skill 鎵ц Runtime / LLM Provider 缁戝畾

### 馃 Codex CLI锛堝苟鍒楃涓€锛?
瀹屽叏寮€婧?Apache-2.0銆丷ust 瀹炵幇銆丱S 鍐呮牳绾ф矙绠便€?70 涓囧懆涓嬭浇銆備綔涓?RAMS 榛樿鎵ц鍚庣銆?
### 馃 Claude Code锛堝苟鍒楃涓€锛?
Agent Teams 鍘熺敓骞惰 + Agent SDK + Headless Mode + MCP 800+ 鏈嶅姟鍣ㄣ€備綔涓?RAMS 绗簩鎵ц鍚庣銆?
### 馃 oh-my-codex锛堢紪鎺掑寮哄眰锛?
MCP state/memory/trace 鍒嗙鏋舵瀯銆佽繘绋嬬敓鍛藉懆鏈熺鐞嗐€侀厤缃敓鎴?marker-based 鍚堝苟銆備綔涓?Codex 涔嬩笂鐨勭紪鎺掑弬鑰冦€?
### 馃 OpenClaw锛圥rovider 鎶借薄鍙傝€冿級

澶?LLM Provider 鏀寔锛圕laude/GPT/Gemini/Ollama锛夈€俁AMS 鐨?Actor 鎶借薄灞傚弬鑰冦€?
### 馃 claw-code / Hermes / Cursor SDK

claw-code锛欳laude Code 鐨?Rust 閲嶅啓锛屽彲鍙傝€?API 璋冪敤妯″紡銆?Cursor SDK锛?026.4.29 鍒氬彂甯冿紝鐢熸€佸お鏃╂湡銆?
---

## RAMS 鏈€浣冲弬鑰冪粍鍚?
```
鈹屸攢鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹?鈹? Role/Skill 瀹氫箟灞?                                         鈹?鈹? 鈹溾攢鈹€ 鏍稿績鍙傝€? oh-my-agent (SSOT + 涓ゅ眰鍒嗙 + Variant)       鈹?鈹? 鈹溾攢鈹€ 鍒嗙被鍙傝€? oh-my-codex (Posture/ModelClass/Role)         鈹?鈹? 鈹斺攢鈹€ 鏍煎紡鍙傝€? agent-skills (鍘熷瓙 Skill 绮掑害)                 鈹?鈹溾攢鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹?鈹? 缂栨帓灞傦紙RAMS Core锛?                                       鈹?鈹? 鈹溾攢鈹€ 鐘舵€佹満: oh-my-codex (闃舵杞崲 + 鍥炴粴淇濇姢)                鈹?鈹? 鈹溾攢鈹€ DAG: oh-my-codex (渚濊禆鍥?+ 鐜娴?                      鈹?鈹? 鈹溾攢鈹€ 鍒嗛厤: oh-my-codex + oh-my-agent (瀹℃煡寰幆)              鈹?鈹? 鈹斺攢鈹€ 璇勫垎: RAMS 鐙垱 (task-driven scoring)                   鈹?鈹溾攢鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹?鈹? 鎵ц Runtime 灞?                                           鈹?鈹? 鈹溾攢鈹€ 榛樿寮曟搸: Codex CLI (寮€婧?+ 绀惧尯澶?+ 娌欑)               鈹?鈹? 鈹溾攢鈹€ 绗簩寮曟搸: Claude Code (Agent Teams + SDK)               鈹?鈹? 鈹溾攢鈹€ 缂栨帓澧炲己: oh-my-codex (MCP 鏋舵瀯 + 鐢熷懡鍛ㄦ湡)             鈹?鈹? 鈹溾攢鈹€ Provider 鎶借薄: OpenClaw (澶?LLM 鏀寔)                   鈹?鈹? 鈹斺攢鈹€ 鑷缓鍙傝€? claw-code (Rust API 璋冪敤妯″紡)                 鈹?鈹斺攢鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹?```

> 姣忎釜 repo 鍙彇鍏舵渶寮虹殑涓€椤癸紝涓嶈瘯鍥句粠浠讳綍涓€涓?repo 鑾峰彇鎵€鏈夌瓟妗堛€?'@ | Set-Content -Path "$dir\04-Competitor-Reference-Classification.md" -Encoding UTF8

# File 5: 12-Month Roadmap
@'
# RAMS 鈥?12 涓湀寮€鍙?Roadmap

> **RAMS (Role/Actor/Model/Skill)**: AI 鍥㈤槦缂栨帓绯荤粺
> 鍥㈤槦锛歋olo/1-2 浜?| 璺ㄥ害锛?2 涓湀 | 绛栫暐锛氶€氱敤妗嗘灦浼樺厛锛孌esign 棰嗗煙楠岃瘉

---

## 闃舵鎬昏

```
Month 1-2    Month 3-4    Month 5-6    Month 7-8    Month 9-10   Month 11-12
鈹屸攢鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹?鈹屸攢鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹?鈹屸攢鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹?鈹屸攢鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹?鈹屸攢鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹?鈹屸攢鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹?鈹? Phase 0  鈹?鈹? Phase 1  鈹?鈹? Phase 2  鈹?鈹? Phase 3  鈹?鈹? Phase 4  鈹?鈹? Phase 5  鈹?鈹? 鍩虹璁炬柦  鈹?鈹? 鏍稿績妗嗘灦  鈹?鈹? 鎵ц寮曟搸  鈹?鈹? 璇勫垎绯荤粺  鈹?鈹? Marketplace鈹?鈹? 鐢熸€佸缓璁? 鈹?鈹斺攢鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹?鈹斺攢鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹?鈹斺攢鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹?鈹斺攢鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹?鈹斺攢鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹?鈹斺攢鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹?   鍩虹煶灞?       瀹氫箟灞?       鎵ц灞?       鏅鸿兘灞?       骞冲彴灞?       鐢熸€佸眰
```

---

## Phase 0: 鍩虹璁炬柦锛圡onth 1-2锛?
**鐩爣**锛氶」鐩鏋?+ 鏍稿績绫诲瀷 + 閰嶇疆浣撶郴 + CLI 楠ㄦ灦

### 鏍稿績绫诲瀷绯荤粺

```typescript
interface Role {
  id: string; name: string; description: string; version: string
  posture: 'orchestrator' | 'worker' | 'scout'
  modelClass: 'frontier' | 'standard' | 'fast'
  routingRole: 'leader' | 'specialist' | 'executor'
  defaultSkills: SkillRef[]
  variants?: RoleVariant[]
}

interface Skill {
  id: string; name: string; version: string
  taskTypes: TaskTypeWeight[]
  defaultScore: number
  dependencies: string[]
}

interface Actor {
  provider: string; model: string
  costPerToken: { input: number; output: number }
}

interface RoleInstance {
  role: Role; actor: Actor; memory: MemoryConfig
  context: TaskContext; loadedSkills: LoadedSkill[]
}
```

### 閰嶇疆浣撶郴

```yaml
# .rams/config.yaml
runtime:
  default_adapter: codex
  default_actor: openai/gpt-5.5
role:
  default: design-lead
skills:
  auto_load: true
  load_priority: [default, custom, marketplace]
scoring:
  enabled: true; storage: local
```

### 閲岀▼纰?- [ ] `pnpm install && pnpm build` 闆堕敊璇?- [ ] 鏍稿績绫诲瀷 100% 娴嬭瘯瑕嗙洊
- [ ] `rams --help` 杈撳嚭鎵€鏈夊懡浠?
---

## Phase 1: 鏍稿績妗嗘灦锛圡onth 3-4锛?
**鐩爣**锛歊ole/Skill 瀹氫箟 + 涓夊眰鍔犺浇 + Adapter 鎺ュ彛

### Role 瀹氫箟鏍煎紡

```yaml
# .rams/roles/design-lead/role.yaml
id: design-lead
posture: worker
modelClass: standard
routingRole: specialist
default_skills:
  - skill_id: token-architecture; priority: P0; required: true
  - skill_id: design-taste; priority: P2; default_enabled: false
actors:
  recommended:
    - provider: anthropic; model: claude-sonnet-4.6
    - provider: openai; model: gpt-5.5
```

### 涓夊眰鍔犺浇

```
Layer 3: Marketplace (.rams/marketplace/installed/)  鈫?鏈€楂樹紭鍏?Layer 2: Custom (.rams/skills/custom/)
Layer 1: Default (.rams/skills/core/)
鍚堝苟绛栫暐锛氬悓鍚?Skill锛岄珮灞傝鐩栦綆灞?```

### Adapter 鎺ュ彛

```typescript
interface RamsAdapter {
  readonly id: string
  initialize(config): Promise<void>
  installRole(role, skills): Promise<void>
  execute(task, roleInstance): Promise<ExecutionResult>
  generateConfig(roles, skills): Promise<GeneratedConfig>
}
```

### 閲岀▼纰?- [ ] 鐜版湁 16 涓?Role 杩佺Щ涓?.rams 鏍煎紡
- [ ] 30+ 瀛愭妧鑳芥媶鍒嗕负鐙珛 Skills
- [ ] 涓夊眰鍔犺浇鍚堝苟绠楁硶姝ｇ‘

---

## Phase 2: 鎵ц寮曟搸锛圡onth 5-6锛?
**鐩爣**锛欳odex Adapter + Claude Adapter + 鐘舵€佹満 + 骞惰鎵ц

### Codex Adapter锛堢涓€浼樺厛锛?- AGENTS.md 鐢熸垚锛圧ole + Skills 鈫?Codex 鏍煎紡锛?- Agent TOML 鐢熸垚
- MCP Server 娉ㄥ唽
- `codex exec` 闈炰氦浜掑皝瑁?
### Claude Adapter锛堢浜屼紭鍏堬級
- CLAUDE.md 鐢熸垚
- `.claude/agents/` 瀹氫箟鐢熸垚
- `claude -p` 绠￠亾杈撳叆灏佽

### 宸ヤ綔娴佺姸鎬佹満

```
plan 鈫?execute 鈫?verify 鈫?fix(寰幆, max 3) 鈫?complete/failed
```

### 閲岀▼纰?- [ ] `rams run design-lead "璁捐鐧诲綍椤?` 閫氳繃 Codex 鎵ц
- [ ] 宸ヤ綔娴佸叏娴佺▼閫氳繃
- [ ] 3 涓苟琛屼换鍔?+ 1 涓緷璧栦换鍔℃纭墽琛?
---

## Phase 3: 璇勫垎绯荤粺锛圡onth 7-8锛?
**鐩爣**锛歀ocal 璇勫垎 + 鑷姩璇勪及 + 鎺ㄨ崘寮曟搸

### 璇勫垎鍏紡

```
鏈夌敤鎴峰弽棣堬細completion脳0.3 + quality脳0.3 + efficiency脳0.1 + feedback脳0.3
鏃犵敤鎴峰弽棣堬細completion脳0.4 + quality脳0.4 + efficiency脳0.2
```

### 璇勫垎鏌ヨ浼樺厛绾?
```
1. 涓汉 + 鐗瑰畾浠诲姟绫诲瀷锛堚墺2娆★級
2. Marketplace 鑱氬悎璇勫垎锛圥hase 4 鏂板锛?3. 涓汉鏁翠綋璇勫垎锛堚墺1娆★級
4. Skill 榛樿璇勫垎锛?.0锛?```

### 閲岀▼纰?- [ ] 浠诲姟鎵ц鍚庤嚜鍔ㄥ啓鍏ヨ瘎鍒?- [ ] 鎺ㄨ崘寮曟搸杩斿洖鏈夋剰涔夌殑鎺掑簭

---

## Phase 4: Marketplace锛圡onth 9-10锛?
**鐩爣**锛歋kill Marketplace MVP + 鑱氬悎璇勫垎

### CLI

```bash
rams skill:search "dark mode"
rams skill:install community/dark-mode-system --role design-lead
rams skill:publish ./my-custom-skill/
```

### Local 鈫?Marketplace 鍗囩骇
璇勫垎鏌ヨ閫忔槑鍗囩骇锛岀绾胯嚜鍔ㄩ檷绾с€?
### 閲岀▼纰?- [ ] 鎼滅储/瀹夎/鍙戝竷鍏ㄦ祦绋?- [ ] 绂荤嚎鑷姩闄嶇骇涓?Local 妯″紡

---

## Phase 5: 鐢熸€佸缓璁撅紙Month 11-12锛?
**鐩爣**锛歊ole Marketplace + Design 楠岃瘉 + 鏂囨。 + 绀惧尯

### 閲岀▼纰?- [ ] `rams role:template design-team` 涓€閿畨瑁?- [ ] 绔埌绔獙璇侀€氳繃
- [ ] 瀹樻柟鏂囨。绔欎笂绾?- [ ] npm 鍛ㄤ笅杞?> 1000

---

## 鐗堟湰瑙勫垝

| 鐗堟湰 | Phase | 鏃堕棿 | 鍐呭 |
|------|-------|------|------|
| `v0.1.0` | Phase 0 | M2 | 鏍稿績绫诲瀷 + CLI + 閰嶇疆 |
| `v0.2.0` | Phase 1 | M4 | Role/Skill 瀹氫箟 + 涓夊眰鍔犺浇 |
| `v0.5.0` | Phase 2 | M6 | Codex/Claude Adapter + 鐘舵€佹満 |
| `v0.8.0` | Phase 3 | M8 | Local 璇勫垎 + 鎺ㄨ崘寮曟搸 |
| `v0.9.0` | Phase 4 | M10 | Skill Marketplace |
| `v1.0.0` | Phase 5 | M12 | Role Marketplace + 鏂囨。 + 鐢熸€?|

---

## 椋庨櫓涓庡簲瀵?
| 椋庨櫓 | 搴斿 |
|------|------|
| Codex CLI 0.x API 鍙樺姩 | Fork 骞堕攣瀹氱増鏈?|
| Solo 杩涘害鎱?| 姣忛樁娈靛彧鍋氭牳蹇冿紝涓ユ牸鎺у埗 scope |
| Marketplace 鍐峰惎鍔?| 棰勭疆瀹樻柟 Skills 浣滀负绉嶅瓙 |
| 绔炲搧璺熻繘璇勫垎姒傚康 | 鍏堝彂浼樺娍 + 鐢熸€侀杞?|
