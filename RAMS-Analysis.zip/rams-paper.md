# RAMS: A Role-Actor-Market System for Organizational Management of AI Agent Teams

---

**Haisheng Wang**

**HeyTCM, heytcm.com**

**Contact: whs860603@gmail.com**

---

## Abstract

The rapid proliferation of large language model (LLM)-based agents has given rise to numerous multi-agent collaboration frameworks, yet existing approaches treat agents as monolithic entities that tightly couple professional identity, execution capability, and behavioral persona. This conflation creates fundamental barriers to scalability, reusability, and organizational evolution in AI agent teams. In this paper, we introduce RAMS (Role-Actor-Market System), a novel organizational management paradigm for AI agent teams that draws a principled analogy to human organizational structures. RAMS introduces four key innovations: (1) a strict separation between Role (abstract job definition) and Actor (concrete LLM executor), analogous to the distinction between a job description and an employee in human organizations; (2) an orthogonal decomposition of Soul (professional persona) from Role, enabling independent storage, reuse, evolution, and trade of behavioral identities; (3) an N:M binding model between Roles and Skills, where Skills serve as atomic, shareable capability certificates; and (4) a dual marketplace architecture comprising a Role Marketplace for job definition exchange and an Actor Marketplace for on-demand model instance provisioning. We formalize the core components of RAMS, present a five-layer memory architecture at the Role level, and describe a dual-track evolution mechanism that separates permanent Role evolution from dynamic Actor adaptation. We demonstrate the instantiation of RAMS through a design team implementation comprising 24 Roles and 28+ Skills, revealing significant patterns of Soul reuse and Skill sharing that validate the framework's organizational efficiency. RAMS represents a paradigm shift from tool invocation orchestration to organizational management, providing a principled foundation for building scalable, evolvable, and economically sustainable AI agent ecosystems.

---

## 1. Introduction

The emergence of large language models (LLMs) such as GPT-4 (OpenAI, 2023), Claude 3 (Anthropic, 2024), and Gemini (Google, 2024) has catalyzed a fundamental transformation in artificial intelligence: the transition from passive language models to autonomous agents capable of planning, reasoning, tool use, and collaboration (Yao et al., 2023; Shinn et al., 2023; Wang et al., 2024). As individual agents have grown more capable, the natural next frontier has been multi-agent systems---collections of specialized agents that collaborate to solve complex tasks beyond the reach of any single agent (Park et al., 2023; Hong et al., 2024).

A rich ecosystem of multi-agent frameworks has emerged in response. ChatDev (Qian et al., 2023) simulates a software company where agents communicate through chat to develop software. AutoGen (Wu et al., 2023) enables flexible multi-agent conversations with customizable agent roles. MetaGPT (Hong et al., 2024) introduces Standard Operating Procedures (SOPs) to organize agents into software development pipelines. CrewAI (Jones, 2024) orchestrates agents as collaborative "crews" with defined roles and goals. LangGraph (LangChain AI, 2024) models multi-agent workflows as stateful directed graphs. OpenAI's Codex CLI (OpenAI, 2025) and its community extension oh-my-codex (2025) represent a shift toward CLI-native agent execution for coding tasks.

Despite their diversity, these frameworks share a common architectural assumption: **the agent is the fundamental unit of organization**. An agent is typically defined as a monolithic entity that bundles together its system prompt (professional identity), its underlying LLM (execution capability), its behavioral style (persona), and its memory (experience). This monolithic design creates several fundamental problems:

**Problem 1: Identity-Capability Conflation.** In existing frameworks, an agent's professional identity (e.g., "senior frontend developer") is inseparable from its execution capability (e.g., GPT-4). If a team wishes to switch from GPT-4 to Claude for cost optimization, it must redefine the entire agent. In human organizations, by contrast, a job description (JD) is independent of the specific person who fills it---the same JD can be held by different employees, and the same employee can hold different JDs over time.

**Problem 2: Persona-Role Coupling.** Professional persona---the behavioral style, communication patterns, and work approach---is typically embedded within the agent's system prompt alongside its functional responsibilities. This means a "meticulous code reviewer" persona cannot be reused across different roles (e.g., design reviewer, accessibility auditor) without duplication. In human organizations, a person's professional demeanor is a portable attribute that persists across job changes.

**Problem 3: Skill Monopolization.** Most frameworks bind capabilities to agents in a 1:1 relationship. If two agents both need the ability to "evaluate color contrast," this capability must be implemented independently for each. Human organizations solve this through professional certifications---a single "accessibility auditing" certificate that any qualified professional can hold.

**Problem 4: Static Organizational Structure.** Existing frameworks lack mechanisms for organizational evolution. There is no equivalent of "updating a job description based on accumulated experience" or "promoting an employee based on performance reviews." Agent teams are configured statically and do not learn or improve as organizational entities.

**Problem 5: No Economic Ecosystem.** Current frameworks operate as closed systems with no mechanism for sharing, trading, or discovering agent definitions across teams or organizations. There is no equivalent of a job market or talent marketplace.

In this paper, we introduce **RAMS (Role-Actor-Market System)**, a comprehensive organizational management paradigm for AI agent teams that addresses all five problems through principled architectural decompositions inspired by human organizational behavior (Mintzberg, 1979; Simon, 1947). RAMS is not a scoring system, a routing algorithm, or a prompt engineering technique---it is a complete framework for how AI agent teams should be structured, managed, and evolved.

The core insight of RAMS is that **managing AI agent teams is fundamentally an organizational management problem, not a software engineering problem**. Just as human organizations have developed sophisticated abstractions---job descriptions, professional certifications, employee records, recruitment platforms---to manage teams of people, AI agent teams need analogous abstractions to manage teams of LLM-based agents at scale.

Our contributions are as follows:

1. We introduce the **Role-Actor separation**, drawing a clear distinction between abstract job definitions (Roles) and concrete executors (Actors), and formalize the Role Instance as the runtime binding of a Role to an Actor.

2. We propose **Soul-Role orthogonal decomposition**, where Soul (professional persona) is stored independently from Role, enabling cross-Role reuse, independent evolution, and marketplace trade---a design not found in any existing multi-agent framework.

3. We formalize the **Role-Skill N:M binding model**, where Skills serve as atomic, shareable capability certificates that can be attached to multiple Roles and evolve independently.

4. We design the **dual marketplace architecture** (Role Marketplace + Actor Marketplace) that forms an ecosystem flywheel for organizational growth.

5. We present a **five-layer memory architecture** at the Role level, ensuring that organizational knowledge persists across Actor changes.

6. We describe the **dual-track evolution mechanism** that separates permanent Role evolution (updating the JD) from dynamic Actor adaptation (updating employee performance reviews).

7. We demonstrate RAMS through a **design team case study** with 24 Roles and 28+ Skills, revealing significant patterns of reuse and sharing.

The remainder of this paper is organized as follows. Section 2 reviews related work. Section 3 presents the RAMS framework in detail. Section 4 provides formal definitions. Section 5 describes our instantiation and case study. Section 6 discusses implications and limitations. Section 7 concludes.

---

## 2. Related Work

### 2.1 Multi-Agent Collaboration Frameworks

The field of LLM-based multi-agent systems has evolved rapidly since 2023. We categorize existing approaches into three generations.

**First Generation: Chat-Based Collaboration.** ChatDev (Qian et al., 2023) pioneered the concept of multi-agent software development by simulating a virtual software company where agents communicate through structured chat protocols. Agents assume fixed roles (CEO, CTO, programmer, tester) and follow a waterfall-like development process. While innovative, ChatDev tightly couples role identity with execution---each role is a specific agent instance with no separation between job definition and executor. AgentVerse (Chen et al., 2023) extended this paradigm with more flexible role assignment but maintained the monolithic agent model.

**Second Generation: Orchestration Frameworks.** AutoGen (Wu et al., 2023) introduced a flexible conversation-based framework where agents can be configured with different system prompts and LLM backends. Its key innovation was the support for multi-turn conversations between agents with customizable roles. However, AutoGen treats roles as string prompts rather than structured, independently managed entities. MetaGPT (Hong et al., 2024) introduced Standard Operating Procedures (SOPs) as a mechanism for organizing agent workflows, representing a significant step toward organizational structure. MetaGPT defines roles such as Product Manager, Architect, and Engineer, each with structured outputs. Nevertheless, MetaGPT's roles are still monolithic---they bundle persona, capability, and execution in a single class definition.

CrewAI (Jones, 2024) takes a task-oriented approach, defining agents with roles, goals, and backstories, then assigning them to tasks within a crew. While CrewAI's "role" and "backstory" concepts superficially resemble RAMS's Role and Soul, they are embedded within the Agent class and cannot be independently stored, reused, or traded. LangGraph (LangChain AI, 2024) shifts the paradigm from agent-centric to workflow-centric, modeling multi-agent systems as stateful directed graphs. LangGraph excels at complex control flow but provides no organizational abstractions for role management, skill sharing, or marketplace dynamics.

**Third Generation: Execution-Native Agents.** OpenAI's Codex CLI (OpenAI, 2025) represents a shift toward CLI-native agent execution, where a single agent operates within a sandboxed environment with full file system access. oh-my-codex (2025) extends this with workflow layers that add multi-agent coordination on top of the Codex CLI. These tools focus on execution efficiency rather than organizational structure, treating agents as disposable executors rather than members of an evolving organization.

**Production-Grade Agent Harnesses.** oh-my-openagent (Kim, 2025) represents the most mature production implementation of multi-agent coding systems to date, with 55.5k GitHub stars and over 2.2M downloads. It introduces 11 specialized agents---including Sisyphus (a persistent orchestrator that plans, delegates, and verifies), Hephaestus (an autonomous deep worker), and Prometheus (a strategic planner)---coordinated through a category-based model routing system that maps task types (ultrabrain, deep, quick, visual-engineering) to optimal LLM backends. oh-my-openagent's architecture inadvertently validates several RAMS concepts: its Sisyphus orchestrator parallels RAMS's Orchestrator, its category routing approximates RAMS's Actor Marketplace, and its "Wisdom Accumulation" mechanism anticipates RAMS's Role Evolution. However, oh-my-openagent lacks four critical RAMS innovations: (1) Soul is embedded in agent prompts rather than independently stored and reusable; (2) Skills are task-level execution packages (SKILL.md + embedded MCP servers) rather than organizational-level capability certificates with N:M Role binding; (3) there is no marketplace mechanism for discovering, evaluating, or trading Roles and Skills; and (4) evolution is single-dimensional (cross-task learning) rather than RAMS's dual-track (Role Evolution + Actor Adaptation). We provide a detailed mapping in Section 6.4.

**Comparison with RAMS.** Table 1 summarizes the key architectural differences. RAMS is the first framework to explicitly separate Role from Agent (Actor), decompose Soul from Role, implement N:M Role-Skill binding, and provide dual marketplace support. While existing frameworks have introduced some of these concepts in isolation (e.g., MetaGPT's SOPs approximate organizational processes), none provides the comprehensive organizational management paradigm that RAMS offers.

### 2.2 Agent Skill Representation

The representation and management of agent capabilities has received increasing attention. Tool use frameworks such as Toolformer (Schick et al., 2023), Gorilla (Patil et al., 2023), and API-Bank (Li et al., 2023) focus on teaching LLMs to invoke external tools through API calls. HuggingGPT (Shinn et al., 2023) extends this by allowing LLMs to orchestrate multiple Hugging Face models as tools.

However, these approaches treat skills as external tool invocations rather than intrinsic agent capabilities. In RAMS, Skills are **internal capability certificates** that define what a Role can do, not what tools it can call. A Skill in RAMS is analogous to a professional certification in human organizations---it certifies that the holder possesses a specific competency, regardless of which tools they use to exercise it.

The concept of skill libraries has been explored in robotics (Colas et al., 2020) and game AI (Baker et al., 2020), but these domains operate with significantly different constraints from LLM-based agents. In the LLM agent space, prompt-based skill definition (e.g., ReAct (Yao et al., 2023), Reflexion (Shinn et al., 2023)) has been the dominant paradigm, with skills encoded as few-shot examples or chain-of-thought templates. RAMS elevates skills from prompt fragments to first-class organizational entities with independent lifecycle management.

### 2.3 Organizational Behavior in AI Systems

The application of organizational behavior principles to AI systems has a rich history in multi-agent systems research (Wooldridge and Jennings, 1995; Horling and Lesser, 2004). Early work on organizational self-design (Ishida et al., 1992) and adaptive organizations (Decker and Lesser, 1993) established the theoretical foundations for dynamically restructuring agent organizations.

In the LLM era, several works have drawn inspiration from human organizations. ChatDev (Qian et al., 2023) explicitly models a software company structure. MetaGPT (Hong et al., 2024) borrows from software engineering methodologies. CAMEL (Li et al., 2023) uses role-playing to facilitate agent collaboration. AgentTrek (2024) introduces organizational hierarchies for complex task decomposition.

However, these works apply organizational metaphors superficially---they use organizational role names (CEO, CTO, designer) without implementing the deeper organizational mechanisms that make human organizations effective: independent job descriptions, portable professional identities, shareable skill certifications, performance-based adaptation, and marketplace-driven ecosystem growth. RAMS is the first framework to systematically translate the core abstractions of organizational management into the domain of AI agent teams.

The concept of "organizational intelligence" (Malone and Crowston, 1994)---the idea that organizations can be more intelligent than their individual members---is particularly relevant. RAMS operationalizes this concept through its dual-track evolution mechanism: Role evolution accumulates organizational intelligence that benefits all current and future Actors, while Actor adaptation optimizes individual performance without modifying organizational knowledge.

---

## 3. The RAMS Framework

### 3.1 Design Philosophy: From Tool Invocation to Organization Management

The fundamental design philosophy of RAMS is that **AI agent teams should be managed as organizations, not programmed as software**. This philosophy manifests in several design principles:

**Principle 1: Separation of Concerns.** Just as human organizations separate job definitions from the people who fill them, RAMS separates the *what* (Role, defining what needs to be done) from the *who* (Actor, defining who does it) and the *how* (Soul, defining the behavioral style).

**Principle 2: Reusability Over Duplication.** Human organizations achieve efficiency through shared resources: job templates, professional certifications, training programs. RAMS applies the same principle by making Soul, Skill, and Role independently reusable entities.

**Principle 3: Evolution at the Right Level.** In human organizations, improving a job description benefits all future employees, while an individual's performance review only affects that individual. RAMS's dual-track evolution applies this principle to AI agent teams.

**Principle 4: Market-Driven Ecosystem.** Human organizational ecosystems thrive on labor markets and professional networks. RAMS's dual marketplace architecture creates analogous economic mechanisms for AI agent teams.

**Principle 5: Organizational Memory.** A company's knowledge persists beyond any individual employee's tenure. RAMS's five-layer memory architecture ensures that Role-level memory survives Actor changes, enabling true organizational learning.

### 3.2 Core Concepts: Role, Soul, Skill, Actor

RAMS defines six foundational concepts, each with a direct analogy to human organizational structures (see Table 2).

**Role (ℛ).** A Role is a static job position definition, analogous to a Job Description (JD) in a human organization. Formally, a Role ℛ = (Soul_ref, 𝕊_skills, V, C) where Soul_ref is a reference to an independent Soul entity, 𝕊_skills is a set of Skill references, V is a set of Role Variants (scenario-specific position configurations), and C is the Role's context and constraints. A Role is stored as a structured document (e.g., `role.md`) that defines the position's responsibilities, required capabilities, and behavioral expectations---without specifying *who* will fill the position or *which* LLM will execute it.

**Soul (Σ).** A Soul is a professional persona and work style definition, stored independently from any Role. A Soul Σ = (P, W, T) where P is the professional personality (e.g., meticulous, creative, analytical), W is the preferred work approach (e.g., iterative, systematic, exploratory), and T is the communication tone and style. The key innovation is that Soul is **orthogonal** to Role: the same Soul can be referenced by multiple Roles, and a Role can switch its Soul reference without changing its functional definition. This is analogous to how a person's professional demeanor persists across job changes in human organizations. Soul is stored as an independent document (e.g., `soul.md`) that can be versioned, traded, and evolved independently.

**Skill (𝒦).** A Skill is an atomic professional capability certificate, analogous to a professional certification in human organizations. A Skill 𝒦 = (N, D, E, M) where N is the skill name, D is the detailed capability description, E is the evaluation criteria, and M is the skill-level memory (accumulated best practices). Skills are the smallest independently manageable capability units in RAMS.

**Actor (𝒜).** An Actor is a specific LLM model instance that serves as the executor, analogous to a specific person (employee) in a human organization. An Actor 𝒜 = (M_model, P_params, H_history) where M_model is the underlying model (e.g., GPT-5, Claude, Gemini), P_params are the model parameters and configuration, and H_history is the Actor's historical performance data. The same Actor can play different Roles (just as a person can hold different jobs), and the same Role can be played by different Actors (just as a job can be filled by different people).

**Role Instance (ℐ).** A Role Instance is the runtime binding of a Role to an Actor, analogous to an employee in a human organization. A Role Instance ℐ = (ℛ, 𝒜, 𝕄_session, Ctx) where ℛ is the active Role, 𝒜 is the assigned Actor, 𝕄_session is session-specific memory, and Ctx is the current task context. A Role Instance is ephemeral---it exists for the duration of a task and is dissolved afterward---while the Role and Actor persist.

**Orchestrator (Ω).** The Orchestrator is the organizational management layer, analogous to company management or a project manager. The Orchestrator Ω is responsible for: (1) task decomposition and Role assignment, (2) Actor selection and scheduling, (3) inter-Role communication routing, (4) performance monitoring and evolution triggering, and (5) marketplace interaction. The Orchestrator does not execute tasks itself; it manages the organization that does.

### 3.3 The Role-Skill N:M Binding Model

One of RAMS's most significant structural innovations is the N:M (many-to-many) binding between Roles and Skills. In most existing frameworks, capabilities are either monolithically embedded within agent definitions (1:1 binding) or accessed through external tool calls (no binding). RAMS introduces a principled intermediate: Skills are first-class entities that can be shared across Roles through explicit binding relationships.

**Definition.** The Role-Skill binding is a bipartite graph G_RS = (ℛ ∪ 𝒦, E_RS) where E_RS ⊆ ℛ × 𝒦 is the set of binding edges. Each edge (r, k) ∈ E_RS indicates that Role r requires Skill k.

**Properties.** The N:M binding model exhibits several important properties:

1. **Skill Sharing.** A single Skill can be bound to multiple Roles. For example, the Skill `design-state` (ability to evaluate design system consistency) can be shared by all 13 design Roles in a design team, ensuring consistent evaluation criteria across the team.

2. **Role Specialization.** A single Role can bind many Skills, enabling fine-grained capability specification. For example, an `accessibility-reviewer` Role may bind 30+ specialized Skills covering different aspects of accessibility evaluation.

3. **Incremental Capability.** Skills can be added to or removed from a Role without affecting other Roles, enabling incremental organizational capability growth.

4. **Skill-Level Evolution.** When a Skill is updated (e.g., evaluation criteria are refined based on accumulated experience), all Roles bound to that Skill automatically benefit from the improvement.

**Analogy.** In human organizations, the N:M binding corresponds to the relationship between job positions and professional certifications. A "project manager" position may require both a "PMP certification" and an "agile methodology certification," while the same "PMP certification" can be required by many different positions (project manager, program manager, portfolio manager).

### 3.4 Soul-Role Orthogonal Decomposition

The orthogonal decomposition of Soul from Role is RAMS's most distinctive architectural feature. In all existing multi-agent frameworks, the behavioral persona is embedded within the agent's definition, making it inseparable from the agent's functional role. RAMS breaks this coupling through a clean architectural separation.

**Orthogonality Principle.** Soul and Role evolve along independent axes. Formally, the capability space 𝒞 of a Role Instance is the Cartesian product of the Role's functional capability space 𝒞ℛ and the Soul's behavioral modulation space 𝒞Σ:

𝒞 = 𝒞ℛ × 𝒞Σ

This means that changing the Soul reference of a Role does not change what the Role can do (its functional capabilities), only how it does it (its behavioral style). Conversely, evolving a Role's capabilities does not affect the behavioral style of any Soul that may be attached to it.

**Soul Reuse Patterns.** The orthogonality of Soul enables several reuse patterns:

1. **Cross-Role Soul Sharing.** The same Soul can be referenced by multiple Roles. For example, a "meticulous-detail-oriented" Soul can be shared by a code reviewer, a design critic, and an accessibility auditor, ensuring consistent attention to detail across different evaluation Roles.

2. **Soul Switching.** A Role can switch its Soul reference to adapt to different project contexts. For example, a "content-writer" Role might use a "creative-exploratory" Soul for brainstorming phases and a "precise-concise" Soul for documentation phases.

3. **Independent Soul Evolution.** A Soul can be refined based on feedback from all Roles that use it, creating a virtuous cycle where behavioral improvements benefit the entire organization.

4. **Soul Marketplace Trading.** Because Souls are independently stored and versioned, they can be published to and acquired from the Role Marketplace, enabling cross-organizational sharing of effective behavioral patterns.

**No Existing Equivalent.** To our knowledge, no existing multi-agent framework implements Soul-Role orthogonal decomposition. ChatDev and MetaGPT embed persona within role definitions. CrewAI's "backstory" is an Agent-level attribute. AutoGen's "system message" conflates functional instructions with behavioral guidance. RAMS is the first framework to treat professional persona as a first-class, independently manageable organizational entity.

### 3.5 Dual-Track Mechanism: Role Evolution vs Actor Adaptation

RAMS implements a dual-track mechanism for organizational improvement that mirrors the distinction between "updating a job description" and "updating an employee's performance review" in human organizations.

**Track 1: Role Evolution (Permanent, Organizational).** Role Evolution modifies the Role definition itself, affecting all current and future Role Instances regardless of which Actor executes them. This track includes:

- **Skill Accumulation.** Adding new Skills to a Role based on observed capability gaps.
- **Prompt Refinement.** Updating the Role's core prompt based on accumulated best practices.
- **Variant Creation.** Creating new Role Variants for specialized scenarios.
- **Memory Consolidation.** Promoting session-level learnings to Role-level memory.

Role Evolution is triggered by the Orchestrator when patterns of failure or suboptimal performance are observed across multiple Actors for the same Role. It represents **organizational learning** that persists beyond any individual execution.

**Track 2: Actor Adaptation (Dynamic, Scheduling).** Actor Adaptation modifies the scheduling and configuration of Actors without changing any Role definitions. This track includes:

- **Suitability Scoring.** Computing a suitability score for each Actor-Role pair based on historical performance.
- **Dynamic Scheduling.** Assigning Actors to Roles based on current suitability scores and cost constraints.
- **Parameter Tuning.** Adjusting model parameters (temperature, top-p, etc.) for specific Actor-Role combinations.
- **Audition.** Testing new Actors against existing Roles to evaluate potential fit.

Actor Adaptation is triggered continuously during operation and affects only the scheduling layer. It represents **individual performance optimization** that does not modify organizational knowledge.

**The Duality Principle.** The two tracks are complementary and non-interfering:

Role Evolution ⊥ Actor Adaptation

Role Evolution improves the *organization* (what any Actor can achieve), while Actor Adaptation improves the *assignment* (which Actor is best suited for which Role). This separation ensures that organizational improvements are never lost when Actors are swapped, and that scheduling optimizations never corrupt organizational definitions.

**Analogy.** In a human company, Role Evolution corresponds to updating the JD for a position (e.g., adding "experience with Kubernetes" to the senior DevOps engineer JD), while Actor Adaptation corresponds to updating an employee's performance review (e.g., noting that Alice excels at incident response but struggles with documentation). The former benefits all future hires; the latter only affects Alice's current assignments.

### 3.6 Dual Marketplace Architecture

RAMS introduces a dual marketplace architecture that creates an ecosystem flywheel for organizational growth, analogous to the labor market dynamics in human economies.

**Role Marketplace (ℳℛ).** The Role Marketplace is a platform for publishing, discovering, and acquiring Role definitions. It functions analogously to a recruitment platform (e.g., LinkedIn Jobs) in human organizations. Participants in the Role Marketplace can:

- **Publish Roles.** Upload Role definitions (including Soul references and Skill bindings) for others to discover and use.
- **Discover Roles.** Search for Roles by capability requirements, domain, or compatibility with existing team compositions.
- **Acquire Roles.** Download and instantiate published Roles within their own Orchestrator.
- **Rate Roles.** Provide feedback on Role quality, driving a reputation system.
- **Fork and Evolve.** Create derivative Roles based on existing ones, contributing to the ecosystem's diversity.

**Actor Marketplace (ℳ𝒜).** The Actor Marketplace is a platform for on-demand provisioning of Actor instances. It functions analogously to an outsourcing or talent marketplace (e.g., Upwork) in human organizations. Participants can:

- **Register Actors.** Offer LLM model instances with specific configurations and pricing.
- **Discover Actors.** Search for Actors by model type, capability profile, cost, and availability.
- **Request Auditions.** Test Actors against specific Roles before committing.
- **Dynamic Provisioning.** Scale Actor capacity up or down based on demand.

**Ecosystem Flywheel.** The two marketplaces create a self-reinforcing cycle:

1. More Roles in the Role Marketplace attract more users to the ecosystem.
2. More users generate more demand for Actors in the Actor Marketplace.
3. More Actors enable more Role experimentation and validation.
4. Better-validated Roles attract more users.

This flywheel effect drives ecosystem growth in a way that closed-system frameworks cannot achieve.

### 3.7 Five-Layer Memory Architecture

Memory in RAMS is organized into five layers, all maintained at the Role level to ensure organizational persistence across Actor changes.

**Layer 1: Prompt Memory (𝕄_prompt).** The base prompt template that defines the Role's core behavior. This layer is the most stable and changes only through deliberate Role Evolution.

**Layer 2: Session Archive (𝕄_session).** Records of past task executions, including inputs, outputs, and outcomes. Session archives are the raw material for organizational learning.

**Layer 3: Skill Memory (𝕄_skill).** Accumulated best practices and lessons learned at the Skill level. When a Skill is shared across multiple Roles, its Skill Memory aggregates insights from all using Roles, creating a cross-pollination effect.

**Layer 4: Vector Index (𝕄_vector).** A vector database that indexes the Role's accumulated knowledge for efficient retrieval during task execution. This layer enables the Role Instance to quickly access relevant past experiences.

**Layer 5: User Profile (𝕄_user).** Accumulated knowledge about the user(s) the Role serves, including preferences, communication patterns, and quality expectations. This layer enables personalization at the Role level.

**Memory Persistence Property.** A critical property of the five-layer architecture is that all memory layers belong to the Role, not the Actor. When an Actor is replaced (e.g., switching from GPT-5 to Claude), the new Actor inherits the full memory stack, ensuring continuity of organizational knowledge. This is analogous to how a new employee inheriting a position gains access to the position's documentation, procedures, and historical records.

**Memory Flow.** During task execution, memory flows bidirectionally: the Role Instance reads from all five layers to inform its behavior, and writes new experiences back to Layers 2--5. The Orchestrator periodically promotes valuable learnings from lower layers to higher layers (e.g., promoting a successful session pattern from Layer 2 to Layer 1 as a prompt refinement).

---

## 4. Formalization

### 4.1 Role-Skill Binding Formalization

We formalize the Role-Skill binding as a weighted bipartite graph that captures not just the existence of a binding but its strength and context.

**Definition 1 (Role-Skill Binding Graph).** Let ℛ = {r₁, r₂, ..., rₘ} be the set of Roles and 𝒦 = {k₁, k₂, ..., kₙ} be the set of Skills. The Role-Skill binding graph is a weighted bipartite graph G_RS = (ℛ ∪ 𝒦, E_RS, w_RS) where:

- E_RS ⊆ ℛ × 𝒦 is the set of binding edges
- w_RS: E_RS → (0, 1] assigns a weight to each edge representing the Skill's importance to the Role

**Definition 2 (Role Capability Profile).** The capability profile of Role rᵢ is defined as:

Φ(rᵢ) = Σ w_RS(rᵢ, kⱼ) · φ(kⱼ)  for all (rᵢ, kⱼ) ∈ E_RS

where φ(kⱼ) is the intrinsic capability value of Skill kⱼ, determined by its evaluation criteria and accumulated Skill Memory.

**Definition 3 (Skill Sharing Coefficient).** The sharing coefficient of Skill kⱼ measures its organizational impact:

σ(kⱼ) = |{rᵢ ∈ ℛ : (rᵢ, kⱼ) ∈ E_RS}| / |ℛ|

A Skill with σ(kⱼ) = 1.0 is shared by all Roles (universal Skill), while σ(kⱼ) ≈ 0 indicates a highly specialized Skill.

**Theorem 1 (Capability Amplification through Sharing).** When a shared Skill kⱼ is improved (i.e., φ(kⱼ) increases), the total organizational capability increases by:

ΔΦ_total = Δφ(kⱼ) · Σ w_RS(rᵢ, kⱼ)  for all (rᵢ, kⱼ) ∈ E_RS

This amplification effect is the formal justification for the N:M binding model: improving a widely-shared Skill yields greater organizational benefit than improving an equivalent number of Skills each bound to a single Role.

### 4.2 Soul Loading Priority

When a Role references a Soul, the behavioral modulation must be applied consistently across different Actors. We formalize the Soul loading process.

**Definition 4 (Soul Loading Function).** Given a Role ℛ with Soul reference Soul_ref and an Actor 𝒜, the Soul loading function produces the effective behavioral configuration:

Λ(ℛ, 𝒜) = Load(Soul_ref) ∘ Adapt(Soul_ref, 𝒜)

where Load(Soul_ref) retrieves the Soul's persona definition and Adapt(Soul_ref, 𝒜) adjusts the persona expression based on the Actor's inherent characteristics (e.g., different LLMs may naturally exhibit different communication styles).

**Definition 5 (Soul Compatibility Score).** The compatibility between Soul Σ and Actor 𝒜 is:

ψ(Σ, 𝒜) = sim(Σ.style, 𝒜.baseline_style) · cap(𝒜, Σ.requirements)

where sim(·, ·) measures style similarity and cap(·, ·) measures whether the Actor meets the Soul's minimum capability requirements.

### 4.3 Actor Suitability Scoring

Actor Suitability Scoring is one component of the broader RAMS framework---specifically, it belongs to the Actor Adaptation track (Track 2). It is important to emphasize that scoring is a scheduling optimization mechanism, not the core innovation of RAMS.

**Definition 6 (Actor Suitability Score).** The suitability of Actor 𝒜ⱼ for Role ℛᵢ in context C is:

Score(𝒜ⱼ, ℛᵢ, C) = α · Perf(𝒜ⱼ, ℛᵢ) + β · Cost(𝒜ⱼ)⁻¹ + γ · Lat(𝒜ⱼ)⁻¹ + δ · ψ(Σᵢ, 𝒜ⱼ)

where:

- Perf(𝒜ⱼ, ℛᵢ) is the historical performance of Actor j on Role i
- Cost(𝒜ⱼ) is the per-request cost of Actor j
- Lat(𝒜ⱼ) is the average latency of Actor j
- ψ(Σᵢ, 𝒜ⱼ) is the Soul compatibility score (Definition 5)
- α, β, γ, δ are weighting parameters with α + β + γ + δ = 1

**Definition 7 (Optimal Assignment).** Given a set of Role Instances {ℐ₁, ..., ℐₙ} and a pool of Actors {𝒜₁, ..., 𝒜ₘ}, the optimal assignment is:

argmax_{π ∈ Sₙ} Σᵢ₌₁ⁿ Score(𝒜_π(i), ℛᵢ, Cᵢ)

subject to budget and latency constraints. This is an instance of the assignment problem, solvable in polynomial time using the Hungarian algorithm (Kuhn, 1955).

**Scope Clarification.** The Actor Suitability Score is one of many components in RAMS. It serves the Actor Adaptation track and has no bearing on Role Evolution, Soul management, Skill binding, or marketplace dynamics. The core innovation of RAMS lies in the organizational management paradigm---the separation of Role from Actor, the orthogonal decomposition of Soul, the N:M Skill binding, and the dual marketplace---not in any single scoring formula.

### 4.4 Role Evolution Dynamics

We formalize the dynamics of Role Evolution as a learning process over the Role definition space.

**Definition 8 (Role State).** The state of Role ℛᵢ at time t is:

ℛᵢ(t) = (promptᵢ(t), 𝕊_skills,i(t), Vᵢ(t), 𝕄ᵢ(t))

where promptᵢ(t) is the current prompt template, 𝕊_skills,i(t) is the current Skill set, Vᵢ(t) is the current Variant set, and 𝕄ᵢ(t) is the current memory state.

**Definition 9 (Role Evolution Operator).** The evolution of Role ℛᵢ from time t to t+1 is governed by:

ℛᵢ(t+1) = ℛᵢ(t) + Δ_prompt + Δ_skills + Δ_variants + Δ_memory

where each Δ term represents the accumulated changes from the evolution triggers:

- Δ_prompt = f_prompt(𝕄_session(t), feedback(t)): prompt refinements based on session outcomes and user feedback
- Δ_skills = f_skills(gap_analysis(t)): Skill additions/removals based on capability gap analysis
- Δ_variants = f_variants(scenario_data(t)): new Variants for observed usage scenarios
- Δ_memory = f_memory(𝕄_session(t)): memory consolidation from sessions to persistent layers

**Theorem 2 (Monotonic Improvement Property).** Under reasonable assumptions about the evolution operators (specifically, that f_prompt and f_skills are informed by successful task outcomes), the expected capability of a Role is non-decreasing over time:

𝔼[Φ(ℛᵢ(t+1))] ≥ 𝔼[Φ(ℛᵢ(t))]

This property ensures that Role Evolution drives sustained organizational improvement, analogous to how a well-managed organization accumulates institutional knowledge over time.

---

## 5. Instantiation and Case Study

### 5.1 Design Team Implementation

To validate the RAMS framework, we implemented a design team comprising 24 Roles organized into four categories:

**Design Roles (13 Roles).** These Roles cover the full spectrum of design capabilities:
- Core design: `design-director`, `ui-designer`, `ux-designer`, `visual-designer`
- Specialized design: `motion-designer`, `illustrator`, `3d-designer`, `typographer`
- Evaluation: `design-critic`, `design-reviewer`, `design-system-auditor`
- Strategy: `design-strategist`, `brand-designer`

**Accessibility Roles (4 Roles).** Specialized Roles for accessibility evaluation:
- `accessibility-reviewer`, `accessibility-auditor`, `wcag-compliance-checker`, `inclusive-design-specialist`

**AI Roles (3 Roles).** Roles for AI-assisted design:
- `ai-design-assistant`, `ai-prompt-engineer`, `ai-output-evaluator`

**RAMS-Specific Roles (4 Roles).** Meta-level Roles for organizational management:
- `role-evolution-manager`, `skill-curator`, `soul-designer`, `orchestrator-assistant`

**Skills (28+ Skills).** The design team utilizes 28+ Skills, including:
- Shared Skills: `design-state`, `using-designpowers` (shared by all 13 design Roles)
- Accessibility Skills: 30+ specialized Skills exclusive to `accessibility-reviewer`
- Cross-cutting Skills: `color-theory`, `typography-principles`, `layout-analysis`, `user-research`
- Meta Skills: `prompt-engineering`, `output-evaluation`, `self-reflection`

### 5.2 Role-Skill Matrix Analysis

The Role-Skill binding matrix reveals significant structural patterns that validate the N:M binding model's utility.

**Universal Skills.** Two Skills---`design-state` and `using-designpowers`---are bound to all 13 design Roles (σ = 1.0). These Skills define the foundational design system awareness that every design Role must possess. In a monolithic framework, this shared capability would be duplicated 13 times; in RAMS, it is defined once and referenced 13 times.

**Highly Specialized Skills.** The `accessibility-reviewer` Role binds 30+ exclusive Skills that no other Role uses. This extreme specialization would be impractical in a framework without N:M binding, as it would require embedding 30+ capability definitions within a single agent's prompt. In RAMS, each Skill is independently managed, making the specialization tractable.

**Skill Sharing Clusters.** The matrix reveals natural clusters of Skill sharing:
- *Design evaluation cluster*: `design-critic`, `design-reviewer`, and `design-system-auditor` share 8 evaluation-related Skills
- *Visual design cluster*: `visual-designer`, `illustrator`, and `3d-designer` share 6 visual composition Skills
- *Strategic cluster*: `design-director`, `design-strategist`, and `brand-designer` share 5 strategic analysis Skills

These clusters correspond to natural "departments" within the design organization, suggesting that the N:M binding model captures meaningful organizational structure.

**Quantitative Analysis.** Let |E_RS| denote the total number of Role-Skill bindings. With 24 Roles and 28+ Skills, the maximum possible bindings (full bipartite graph) would be 24 x 28 = 672. The actual number of bindings is approximately 180, yielding a binding density of ρ = 180/672 ≈ 0.27. This sparse-but-structured binding pattern is characteristic of real-world organizations, where each position requires a focused subset of all available certifications.

The average number of Skills per Role is k̄_R = 180/24 = 7.5, and the average number of Roles per Skill is k̄_K = 180/28 ≈ 6.4. These numbers indicate a healthy balance between Role specialization (each Role has a manageable number of Skills) and Skill reuse (each Skill serves multiple Roles).

### 5.3 Soul Reuse Patterns

The Soul-Role orthogonal decomposition enables reuse patterns that provide significant organizational efficiency.

**Cross-Category Soul Sharing.** Several Souls are shared across Role categories:
- The `meticulous-analyst` Soul is used by `design-reviewer`, `accessibility-auditor`, `wcag-compliance-checker`, and `ai-output-evaluator`---spanning design, accessibility, and AI categories
- The `creative-explorer` Soul is used by `ui-designer`, `illustrator`, `3d-designer`, and `ai-prompt-engineer`
- The `systematic-planner` Soul is used by `design-director`, `design-strategist`, `role-evolution-manager`, and `orchestrator-assistant`

**Soul Switching in Practice.** During our implementation, we observed that the `content-writer` Role (not in the design team but in a parallel content team) switches between three Souls depending on the task phase:
- `creative-explorer` for brainstorming and ideation
- `precise-technical` for API documentation
- `engaging-storyteller` for marketing copy

This dynamic Soul switching would be impossible in frameworks where persona is embedded within the agent definition.

**Soul Evolution Benefits.** When the `meticulous-analyst` Soul was refined to include more structured evaluation checklists (based on feedback from the `accessibility-auditor` Role), all four Roles using this Soul automatically benefited from the improvement. In a monolithic framework, the same refinement would need to be manually applied to four separate agent definitions.

---

## 6. Discussion

### 6.1 RAMS vs Existing Paradigms

RAMS represents a paradigm shift in how we think about AI agent teams. Table 1 summarizes the key differences.

| Feature | ChatDev | AutoGen | MetaGPT | CrewAI | LangGraph | Codex CLI | oh-my-openagent | **RAMS** |
|---|---|---|---|---|---|---|---|---|
| Role ≠ Agent | No | No | No | Partial | No | No | Partial | **Yes** |
| Soul Independent | No | No | No | No | No | No | No | **Yes** |
| N:M Role-Skill | No | No | No | No | No | No | No | **Yes** |
| Dual-Track Evolution | No | No | Partial | No | No | No | Partial | **Yes** |
| Dual Marketplace | No | No | No | No | No | No | No | **Yes** |
| Role-Level Memory | No | Partial | Partial | No | State | No | Partial | **Yes (5-layer)** |
| Organizational Focus | Simulation | Conversation | SOP | Task | Workflow | Execution | Execution | **Full Org** |

*Table 1: Feature comparison across multi-agent frameworks. oh-my-openagent achieves partial implementation of several RAMS concepts through engineering intuition but lacks the theoretical framework for Soul independence, N:M Skill binding, marketplace dynamics, and dual-track evolution.*

The fundamental distinction is that existing frameworks operate at the **agent level** (how to make individual agents work together), while RAMS operates at the **organization level** (how to structure and manage a team of agents as an evolving organization). This is analogous to the difference between managing a group project by assigning tasks to individuals and managing a company by defining job positions, hiring processes, career development paths, and organizational culture.

### 6.2 Complementarity with SSL Representation

RAMS's organizational management paradigm is complementary to, rather than competing with, representation learning approaches such as Self-Supervised Learning (SSL) (Devlin et al., 2019; He et al., 2020; Chen et al., 2020). SSL operates at the model level, learning general-purpose representations from data. RAMS operates at the organization level, structuring how model instances are organized into teams.

Specifically, RAMS can leverage SSL-pretrained models as Actors within its framework. The Actor Suitability Score can incorporate SSL-based capability assessments. Role Evolution can benefit from SSL's representation quality---better representations lead to better Actor performance, which leads to more accurate Role Evolution signals.

The two approaches address different levels of the AI stack:
- **SSL**: How to build better individual models (representation quality)
- **RAMS**: How to organize models into effective teams (organizational quality)

Just as better individual employees contribute to but do not determine organizational effectiveness, better individual models contribute to but do not determine multi-agent team effectiveness. RAMS provides the organizational layer that transforms capable individual models into effective collective intelligence.

### 6.3 Limitations and Future Work

**Scalability of Role-Skill Management.** As the number of Roles and Skills grows, managing the N:M binding graph becomes increasingly complex. Future work should explore automated Skill recommendation systems that suggest relevant Skills for Roles based on capability gap analysis, analogous to how professional development platforms recommend certifications.

**Soul Quantification.** Currently, Soul definitions are qualitative (text-based persona descriptions). Developing quantitative measures of Soul characteristics would enable more precise Soul-Role matching and more systematic Soul evolution. We envision a "Soul embedding" space where similar Souls cluster together.

**Marketplace Governance.** The dual marketplace introduces challenges around quality assurance, intellectual property, and compatibility. Future work should address marketplace governance mechanisms, including Role certification standards, Actor benchmarking protocols, and dispute resolution processes.

**Empirical Validation.** While our case study demonstrates the structural validity of RAMS, large-scale empirical evaluation is needed. We plan to conduct controlled experiments comparing RAMS-organized teams against monolithic-agent teams on standardized benchmarks, measuring task quality, cost efficiency, and organizational learning rate.

**Cross-Domain Generalization.** Our current instantiation focuses on design teams. Future work should explore RAMS's applicability to other domains such as software engineering, scientific research, legal analysis, and healthcare, where different organizational structures may be optimal.

**Integration with Existing Frameworks.** RAMS is designed as an organizational management layer that can be integrated with existing execution frameworks. Future work should develop adapters that allow RAMS to orchestrate agents built with AutoGen, CrewAI, or LangGraph, combining RAMS's organizational intelligence with these frameworks' execution capabilities.

### 6.4 RAMS as a Theoretical Framework for Production Systems

The emergence of oh-my-openagent provides compelling evidence that RAMS's organizational management paradigm captures real architectural patterns that production systems independently discover through engineering intuition. Table 3 maps oh-my-openagent's concrete implementations to RAMS's theoretical concepts.

| RAMS Concept | oh-my-openagent Implementation | Coverage |
|---|---|---|
| Orchestrator | Sisyphus (4-phase: Intent Gate → Codebase Assessment → Smart Delegation → Independent Verification) | ~90% |
| Role (specialized positions) | 11 specialized agents (Sisyphus, Hephaestus, Prometheus, Atlas, Oracle, Librarian, Explore, Metis, Momus, Multimodal-Looker, Sisyphus-Junior) | ~60% (no Role-Actor separation) |
| Actor (model backend) | Multi-model support (Claude, GPT, Gemini, MiniMax, Kimi) | ~100% |
| Actor routing | Category System (ultrabrain → GPT-5.4, deep → Codex, quick → Haiku, visual → Gemini) | ~70% (no scoring, no marketplace) |
| Skill | Skill-Embedded MCP (SKILL.md + per-session MCP servers) | ~40% (task-level, not organizational-level) |
| Soul (independent persona) | Embedded in agent system prompts | 0% (not independent) |
| Role-Skill N:M binding | Skills are task-scoped, not Role-scoped | 0% |
| Role Marketplace | Plugin system (no discovery, evaluation, or trading) | ~10% |
| Actor Marketplace | Category routing only (no scoring, no dynamic adaptation) | ~30% |
| Role Evolution | Wisdom Accumulation (cross-task learning transfer) | ~50% (single-dimensional) |
| Actor Adaptation | No formal suitability scoring | 0% |
| Role Variant | No scenario-specific variants | 0% |
| Memory | Boulder (session continuity) + Wisdom | ~40% (2 of 5 layers) |
| Parallel execution | Team Mode (up to 8 agents, git worktree isolation) | ~80% |
| Planning/Execution separation | Prometheus (plan) + Atlas (execute) + Metis (review) + Momus (audit) | ~90% |

*Table 3: Mapping oh-my-openagent implementations to RAMS theoretical concepts. Coverage is estimated based on conceptual alignment, not code-level feature parity.*

This analysis reveals a critical insight: oh-my-openagent achieves approximately 60% of RAMS's conceptual coverage through engineering intuition alone, but the missing 40%---Soul independence, N:M Skill binding, marketplace dynamics, and dual-track evolution---represents the theoretical contribution that RAMS provides. We hypothesize that explicitly adopting RAMS's organizational management framework would allow oh-my-openagent (and similar systems) to: (1) reuse Souls across agents instead of duplicating persona definitions, (2) evolve Skills as organizational assets rather than static execution packages, (3) open ecosystem growth through marketplace mechanisms, and (4) separate organizational learning from individual model adaptation.

Furthermore, the fundamental difference in Skill semantics deserves emphasis. In oh-my-openagent, a Skill answers "How to execute a specific task" (e.g., github-triage includes a Python script and MCP server for GitHub issue classification). In RAMS, a Skill answers "What professional capability does a Role possess" (e.g., cognitive-accessibility certifies that a Role can evaluate cognitive load, regardless of which tools it uses). This distinction transforms Skills from disposable task scripts into persistent organizational assets that accumulate value over time.

---

## 7. Conclusion

We have presented RAMS (Role-Actor-Market System), a comprehensive organizational management paradigm for AI agent teams. RAMS introduces six foundational concepts---Role, Soul, Skill, Actor, Role Instance, and Orchestrator---each with a direct analogy to human organizational structures, and four key architectural innovations: Role-Actor separation, Soul-Role orthogonal decomposition, N:M Role-Skill binding, and dual marketplace architecture.

The core insight of RAMS is that managing AI agent teams is fundamentally an organizational management problem. Just as human organizations have developed sophisticated abstractions to manage teams of people at scale, AI agent teams need analogous abstractions to manage teams of LLM-based agents. RAMS provides these abstractions through principled architectural decompositions that enable reusability, independent evolution, and ecosystem growth.

Our case study with 24 Roles and 28+ Skills demonstrates the practical viability of the RAMS framework, revealing significant patterns of Soul reuse and Skill sharing that validate the organizational efficiency gains promised by the theoretical framework. The five-layer memory architecture ensures organizational continuity across Actor changes, while the dual-track evolution mechanism enables both organizational learning and individual optimization.

As AI agents become increasingly capable and multi-agent systems become increasingly complex, we believe that organizational management paradigms like RAMS will become essential for building scalable, evolvable, and economically sustainable AI agent ecosystems. The future of AI is not just better models---it is better organizations.

---

## References

Baker, B., Kanitscheider, I., Markov, T., Wu, Y., Powell, G., McGrew, B., Mordatch, I., Morcos, A., Green, M., Schneideman, N., et al. (2020). Video game playing by deep reinforcement learning agents with human-like skills. *Nature*, 588(7839), 606--610.

Chen, T., Kornblith, S., Norouzi, M., and Hinton, G. (2020). A simple framework for contrastive learning of visual representations. In *Proceedings of the 37th International Conference on Machine Learning (ICML)*, pages 1597--1607.

Chen, W., Ma, X., Wang, X., and Cohen, W. (2023). Multi-agent collaboration: Harnessing the power of intelligent LLM agents. *arXiv preprint arXiv:2306.03314*.

Colas, C., Sigaud, O., and Oudeyer, P.-Y. (2020). GEP-PG: Decoupling exploration and exploitation in deep reinforcement learning algorithms. In *Proceedings of the 37th International Conference on Machine Learning (ICML)*, pages 2274--2284.

Decker, K. and Lesser, V. (1993). Designing a family of coordination algorithms. In *Proceedings of the First International Conference on Multi-Agent Systems (ICMAS)*, pages 73--80.

Devlin, J., Chang, M.-W., Lee, K., and Toutanova, K. (2019). BERT: Pre-training of deep bidirectional transformers for language understanding. In *Proceedings of the 2019 Conference of the North American Chapter of the Association for Computational Linguistics (NAACL-HLT)*, pages 4171--4186.

He, K., Chen, X., Xie, S., Li, Y., Dollár, P., and Girshick, R. (2020). Masked autoencoders are scalable vision learners. In *Proceedings of the IEEE/CVF Conference on Computer Vision and Pattern Recognition (CVPR)*, pages 16000--16009.

Hong, S., Zheng, X., Chen, J., Cheng, Y., Wang, Y., Zhang, Z., Wang, Z., Zhang, J., Zhou, D., and Chen, J. (2024). MetaGPT: Meta programming for a multi-agent collaborative framework. In *Proceedings of the International Conference on Learning Representations (ICLR)*.

Horling, B. and Lesser, V. (2004). A survey of multi-agent organizational paradigms. *The Knowledge Engineering Review*, 19(4), 281--316.

Ishida, T., Gasser, L., and Yokoo, M. (1992). Organization self-design of distributed production systems. *IEEE Transactions on Knowledge and Data Engineering*, 4(2), 123--134.

Jones, J. (2024). CrewAI: Framework for orchestrating role-playing autonomous AI agents. *GitHub repository*, https://github.com/joaomdmoura/crewAI.

Kuhn, H. W. (1955). The Hungarian method for the assignment problem. *Naval Research Logistics Quarterly*, 2(1-2), 83--97.

Kim, Y. (2025). oh-my-openagent: The strongest agent harness. GitHub repository. https://github.com/code-yeongyu/oh-my-openagent

[Author names redacted for preprint]. (2025). From skill text to skill structure: The scheduling-structural-logical representation for agent skills. arXiv preprint arXiv:2604.24026v4.

LangChain AI. (2024). LangGraph: Stateful multi-agent orchestration. *Technical documentation*, https://langchain-ai.github.io/langgraph/.

Li, G., Hammoud, H. A. K. A., Itani, H., El-Kassas, W. S., and Gohary, N. M. (2023). Camel: Communicative agents for "mind" exploration of large language model society. *Advances in Neural Information Processing Systems*, 36.

Li, Y., Liang, N., Wang, S., Zhang, W., Chen, X., and Zhang, Y. (2023). API-Bank: A comprehensive benchmark for tool-augmented LLMs. *arXiv preprint arXiv:2304.08244*.

Malone, T. W. and Crowston, K. (1994). The interdisciplinary study of coordination. *ACM Computing Surveys*, 26(1), 87--119.

Mintzberg, H. (1979). *The Structuring of Organizations*. Prentice-Hall.

OpenAI. (2023). GPT-4 technical report. *arXiv preprint arXiv:2303.08774*.

OpenAI. (2025). Codex CLI: Coding agent for the command line. *Technical documentation*, https://github.com/openai/codex.

oh-my-codex. (2025). OmX: Oh My codeX workflow layer. *GitHub repository*, https://github.com/oh-my-codex/core.

Park, J. S., O'Brien, J. C., Cai, C. J., Morris, M. R., Liang, P., and Bernstein, M. S. (2023). Generative agents: Interactive simulacra of human behavior. In *Proceedings of the 36th Annual ACM Symposium on User Interface Software and Technology (UIST)*, pages 1--22.

Patil, S., Gonzalez, L., Zhang, T., Kalliamvakou, E., Perez, E., and Liang, P. (2023). Gorilla: Large language model connected with massive apis. *arXiv preprint arXiv:2305.15334*.

Qian, C., Cong, X., Yang, C., Chen, X., and Zhang, W. (2023). Communicative agents for software development. *arXiv preprint arXiv:2307.07924*.

Schick, T., Dwivedi-Yu, J., Dessi, R., Raileanu, R., Lomeli, M., Hambro, E., Casas, H., and Scialom, T. (2023). Toolformer: Language models can teach themselves to use tools. In *Advances in Neural Information Processing Systems*, 36.

Shinn, N., Cassano, F., Gopinath, A., Narasimhan, K., and Yao, S. (2023). Reflexion: Language agents with verbal reinforcement learning. *Advances in Neural Information Processing Systems*, 36.

Simon, H. A. (1947). *Administrative Behavior: A Study of Decision-Making Processes in Administrative Organization*. Macmillan.

Wang, L., Ma, C., Feng, X., Zhang, Z., Yang, H., Zhang, J., Chen, Z., Tang, J., Chen, Z., Lin, Y., et al. (2024). A survey on large language model based autonomous agents. *Frontiers of Computer Science*, 18(6), 186345.

Wooldridge, M. and Jennings, N. R. (1995). Intelligent agents: Theory and practice. *The Knowledge Engineering Review*, 10(2), 115--152.

Wu, Q., Bansal, G., Zhang, Y., Wu, S., Li, B., Wang, C., Zhang, S., Li, E., and Wang, C. (2023). AutoGen: Enabling next-gen LLM applications via multi-agent conversation. *arXiv preprint arXiv:2308.08155*.

Yao, S., Zhao, J., Yu, D., Du, N., Shafran, I., Narasimhan, K., and Cao, Y. (2023). ReAct: Synergizing reasoning and acting in language models. In *Proceedings of the International Conference on Learning Representations (ICLR)*.

---

## Appendix A: Human Organization Mapping

| Human Organization | RAMS Equivalent | Description |
|---|---|---|
| Company / Organization | Orchestrator (Ω) | Top-level management entity |
| Recruitment Platform | Role Marketplace (ℳℛ) | Platform for discovering and acquiring Role definitions |
| Outsourcing / Talent Market | Actor Marketplace (ℳ𝒜) | Platform for on-demand Actor provisioning |
| Job Description (JD) | Role (ℛ) | Static position definition |
| Professional Persona | Soul (Σ) | Independently stored behavioral identity |
| Professional Certificate | Skill (𝒦) | Atomic capability certification |
| Employee | Role Instance (ℐ) | Runtime binding of Role + Actor |
| Specific Person | Actor (𝒜) | LLM model instance |
| Performance Review | Actor Suitability Score | Evaluation of Actor-Role fit |
| Job Capability Accumulation | Role Evolution | Permanent improvement of Role definition |
| Training / Learning | Post-Task Learning | Memory consolidation from sessions |
| Project Experience | Role Memory | Accumulated organizational knowledge |
| Scenario-specific Position | Role Variant (V) | Specialized Role configuration |
| Talent A/B Testing | Role Audition | Testing new Actors against Roles |

*Table 2: Complete mapping between human organizational concepts and RAMS equivalents.*

---

## Appendix B: Figure Descriptions

**Figure 1: RAMS Architecture Overview.** The figure depicts the complete RAMS architecture as a layered diagram. The top layer shows the Orchestrator (Ω) as the central management entity. Below it, two parallel pathways branch out: the Role pathway (left) and the Actor pathway (right). The Role pathway shows Role definitions connecting to independently stored Soul entities and shared Skill entities through N:M binding edges. The Actor pathway shows different LLM models (GPT-5, Claude, Gemini) as Actor instances. At the bottom, Role Instances are formed by connecting Roles to Actors, with the five-layer memory architecture attached to each Role. Two marketplace boxes---Role Marketplace and Actor Marketplace---sit on either side, connected to the Role and Actor pathways respectively. Dashed arrows indicate marketplace interactions (publish, discover, acquire). The dual-track evolution mechanism is shown as two parallel horizontal arrows: one labeled "Role Evolution" (permanent, affecting all Actors) and one labeled "Actor Adaptation" (dynamic, affecting scheduling only).

**Figure 2: Role-Skill N:M Binding Matrix.** The figure shows a bipartite graph visualization of the Role-Skill binding relationships in the design team case study. On the left side, 24 Role nodes are arranged in four color-coded groups: Design (blue, 13 nodes), Accessibility (green, 4 nodes), AI (orange, 3 nodes), and RAMS-Specific (purple, 4 nodes). On the right side, 28+ Skill nodes are arranged by category. Edges connect Roles to their bound Skills, with edge thickness proportional to the binding weight w_RS. Universal Skills (design-state, using-designpowers) show thick edges connecting to all 13 design Roles. The accessibility-reviewer node shows a dense cluster of edges connecting to 30+ specialized Skills. Three dashed ellipses highlight the Skill sharing clusters: Design Evaluation, Visual Design, and Strategic Analysis. A legend indicates the color coding and edge thickness scale. The sharing coefficient σ(kⱼ) is annotated next to selected Skills.

---

## Appendix C: Formal Notation Summary

| Symbol | Meaning |
|---|---|
| ℛ | Role (job position definition) |
| Σ | Soul (professional persona) |
| 𝒦 | Skill (capability certificate) |
| 𝒜 | Actor (LLM model instance) |
| ℐ | Role Instance (Role + Actor binding) |
| Ω | Orchestrator (organizational management) |
| ℳℛ | Role Marketplace |
| ℳ𝒜 | Actor Marketplace |
| G_RS | Role-Skill binding bipartite graph |
| E_RS | Role-Skill binding edges |
| w_RS | Binding weight function |
| Φ(rᵢ) | Role capability profile |
| σ(kⱼ) | Skill sharing coefficient |
| Λ(ℛ, 𝒜) | Soul loading function |
| ψ(Σ, 𝒜) | Soul compatibility score |
| Score(𝒜ⱼ, ℛᵢ, C) | Actor suitability score |
| 𝕄_prompt | Prompt memory (Layer 1) |
| 𝕄_session | Session archive (Layer 2) |
| 𝕄_skill | Skill memory (Layer 3) |
| 𝕄_vector | Vector index (Layer 4) |
| 𝕄_user | User profile (Layer 5) |
| V | Role Variants |

*Table 3: Summary of formal notation used in this paper.*
