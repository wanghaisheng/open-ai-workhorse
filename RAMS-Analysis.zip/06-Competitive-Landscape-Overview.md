## oh-my-openagent（2025 年最强竞品）

### 基本信息
- **GitHub**: https://github.com/code-yeongyu/oh-my-openagent
- **Stars**: 55.5k | **下载**: 2.2M+ | **Commits**: 5,198 | **代码量**: 278k LOC
- **技术栈**: TypeScript + Bun + OpenCode
- **定位**: 最强 Agent Harness（多 Agent 编排插件）
- **领域**: 专注软件开发

### 核心架构
- **11 个专业 Agent**: Sisyphus（编排器）、Hephaestus（深度工作者）、Prometheus（规划者）、Atlas（执行者）、Oracle（架构顾问）、Librarian（文档搜索）、Explore（代码搜索）、Metis（计划顾问）、Momus（计划审查）、Multimodal-Looker、Sisyphus-Junior
- **Category System**: 基于意图的模型路由（ultrabrain→GPT-5.4, deep→Codex, quick→Haiku, visual→Gemini）
- **Skill-Embedded MCP**: Skill 自带 MCP 服务器，按需启动
- **Team Mode**: 最多 8 Agent 并行，支持 git worktree 隔离
- **Boulder**: 会话恢复系统（中断后精确恢复）
- **Wisdom Accumulation**: 跨任务学习传递

### 与 RAMS 的关系
oh-my-openagent 是 RAMS 在 coding 领域的"前理论实现"——凭工程直觉触及了 RAMS 约 60% 的概念。

**已实现（暗合 RAMS）**:
- ✅ 编排器 + 专家委派（Sisyphus ≈ Orchestrator）
- ✅ 模型路由（Category System ≈ Actor Marketplace 简化版）
- ✅ 规划/执行分离（Prometheus/Atlas ≈ design-strategist/design-builder）
- ✅ 并行执行（Team Mode）
- ✅ 会话恢复（Boulder ≈ Role Instance 状态管理）

**未实现（RAMS 独有）**:
- ❌ Soul 独立（人格嵌入在 prompt 中，不可复用）
- ❌ N:M Skill 绑定（Skill 是任务级执行包，非组织级能力）
- ❌ 市场机制（无 Role/Skill 交易）
- ❌ 双轨演化（仅有单维度 Wisdom Accumulation）
- ❌ Role Variant（无场景化变体）

### 对 RAMS 的启示
1. 验证了多 Agent 协作是刚需（55.5k stars）
2. 验证了模型路由是核心能力
3. 验证了规划与执行分离是正确模式
4. RAMS 应借鉴其 Category System、Team Mode、Hashline 编辑等工程实践
