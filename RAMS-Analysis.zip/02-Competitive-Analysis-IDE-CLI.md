﻿# AI 编码工具可扩展性对比报告（2026年5月）

## 综合对比矩阵

| 评估维度 | Claude Code | Codex CLI | Cursor | Windsurf | Gemini CLI |
|----------|:-----------:|:---------:|:------:|:--------:|:----------:|
| 自定义 Agent | A | B+ | A- | C+ | C |
| 插件/扩展 | A | B+ | A- | B | B |
| 可编程/自动化 | A | B+ | A+ | D | D |
| 多模型支持 | C | C | A | A | D |
| 配置成熟度 | A | A- | B+ | B | B- |
| 社区生态 | A- | A+ | A | B+ | B |
| 子 Agent 派生 | A | B+ | A | C | C- |
| MCP 支持 | A+ | B+ | A | A- | B+ |
| 开源程度 | C | A | D | D | A |
| 综合可扩展性 | A | A- | A | B+ | B- |

## RAMS 选型建议

第一梯队：Claude Code（Agent 定义+Skills+MCP+SDK 最完整）
第二梯队：Codex CLI（完全开源+最大社区+oh-my-codex 验证）
第三梯队：Cursor（Cursor SDK 是 2026 年最重要 Agent 基础设施）

推荐：Codex 优先 + 多后端适配。RAMS Core 不绑定任何执行引擎。
