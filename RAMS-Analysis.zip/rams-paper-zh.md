# RAMS：面向AI智能体团队组织管理的角色-执行者-市场系统

---

**王海生**

**HeyTCM, heytcm.com**

**联系邮箱：whs860603@gmail.com**

---

## 摘要

基于大语言模型（LLM）的智能体（Agent）的快速普及催生了众多多智能体协作框架，然而现有方法将智能体视为单体实体，紧密耦合了专业身份、执行能力和行为人格。这种混淆在AI智能体团队的可扩展性、可复用性和组织进化方面造成了根本性障碍。本文提出了RAMS（Role-Actor-Market System，角色-执行者-市场系统），一种面向AI智能体团队的新型组织管理范式，该范式借鉴人类组织结构建立了系统性类比。RAMS引入了四项关键创新：（1）角色（Role，抽象岗位定义）与执行者（Actor，具体LLM执行器）的严格分离，类比于人类组织中职位描述与员工之间的区别；（2）灵魂（Soul，专业人格）与角色的正交分解，使行为身份能够独立存储、复用、进化和交易；（3）角色与技能的N:M绑定模型，其中技能作为原子化的、可共享的能力证书；（4）由角色市场（用于岗位定义交换）和执行者市场（用于按需模型实例供给）组成的双市场架构。我们对RAMS的核心组件进行了形式化定义，提出了角色层面的五层记忆架构，并描述了将永久性角色进化与动态执行者适应分离的双轨进化机制。我们通过一个包含24个角色和28+项技能的设计团队实例展示了RAMS的实际部署，揭示了显著的灵魂复用和技能共享模式，验证了该框架的组织效率。RAMS代表了从工具调用编排到组织管理的范式转变，为构建可扩展、可进化且经济可持续的AI智能体生态系统提供了理论基础。

---

## 1. 引言

GPT-4（OpenAI, 2023）、Claude 3（Anthropic, 2024）和Gemini（Google, 2024）等大语言模型的出现催化了人工智能的根本性变革：从被动的语言模型转变为具备规划、推理、工具使用和协作能力的自主智能体（Yao et al., 2023; Shinn et al., 2023; Wang et al., 2024）。随着单个智能体能力的增强，自然的下一个前沿方向便是多智能体系统——由专业化智能体组成的集合，协同解决超出任何单个智能体能力范围的复杂任务（Park et al., 2023; Hong et al., 2024）。

为应对这一需求，一个丰富的多智能体框架生态系统应运而生。ChatDev（Qian et al., 2023）模拟一家软件公司，智能体通过结构化聊天协议进行通信以开发软件。AutoGen（Wu et al., 2023）支持具有可定制智能体角色的灵活多智能体对话。MetaGPT（Hong et al., 2024）引入标准操作流程（SOP）将智能体组织成软件开发流水线。CrewAI（Jones, 2024）将智能体编排为具有明确角色和目标的协作"团队"。LangGraph（LangChain AI, 2024）将多智能体工作流建模为有状态有向图。OpenAI的Codex CLI（OpenAI, 2025）及其社区扩展oh-my-codex（2025）代表了向CLI原生智能体执行的转变。

尽管这些框架形式多样，但它们共享一个共同的架构假设：**智能体是组织的基本单位**。一个智能体通常被定义为一个单体实体，将其系统提示（专业身份）、底层LLM（执行能力）、行为风格（人格）和记忆（经验）捆绑在一起。这种单体设计造成了几个根本性问题：

**问题1：身份-能力混淆。** 在现有框架中，智能体的专业身份（如"高级前端开发者"）与其执行能力（如GPT-4）不可分离。如果一个团队希望从GPT-4切换到Claude以优化成本，就必须重新定义整个智能体。而在人类组织中，职位描述（JD）与填充该职位的具体人员是独立的——同一个JD可以由不同的员工担任，同一个员工在不同时期也可以担任不同的JD。

**问题2：人格-角色耦合。** 专业人格——行为风格、沟通模式和工作方式——通常嵌入在智能体的系统提示中，与其功能职责混在一起。这意味着一个"严谨的代码审查者"人格无法在不同的角色（如设计审查者、无障碍审计员）之间复用，除非进行复制。在人类组织中，一个人的职业风度是可迁移的属性，在岗位变更中持续存在。

**问题3：技能垄断。** 大多数框架以1:1的关系将能力绑定到智能体。如果两个智能体都需要"评估颜色对比度"的能力，该能力必须为每个智能体独立实现。人类组织通过专业认证解决这一问题——一份"无障碍审计"证书，任何合格的专业人士都可以持有。

**问题4：静态组织结构。** 现有框架缺乏组织进化机制。不存在"基于积累的经验更新职位描述"或"基于绩效考核晋升员工"的等价物。智能体团队是静态配置的，不会作为组织实体进行学习或改进。

**问题5：缺乏经济生态。** 当前框架作为封闭系统运行，没有跨团队或组织共享、交易或发现智能体定义的机制。不存在人才市场或招聘平台的等价物。

本文提出了**RAMS（Role-Actor-Market System，角色-执行者-市场系统）**，一种面向AI智能体团队的综合组织管理范式，通过借鉴人类组织行为学的原则性架构分解（Mintzberg, 1979; Simon, 1947）来解决上述全部五个问题。RAMS不是一个评分系统、路由算法或提示工程技巧——它是一个关于AI智能体团队应如何构建、管理和进化的完整框架。

RAMS的核心理念是：**管理AI智能体团队从根本上是一个组织管理问题，而非软件工程问题**。正如人类组织发展出了成熟的抽象概念——职位描述、专业认证、员工档案、招聘平台——来管理人员团队，AI智能体团队也需要类似的抽象概念来管理大规模的LLM智能体团队。

我们的贡献如下：

1. 提出了**角色-执行者分离**，明确区分抽象岗位定义（角色）和具体执行器（执行者），并将角色实例形式化为角色到执行者的运行时绑定。

2. 提出了**灵魂-角色正交分解**，灵魂（专业人格）独立于角色存储，支持跨角色复用、独立进化和市场交易——这是现有任何多智能体框架中均未发现的设计。

3. 形式化了**角色-技能N:M绑定模型**，技能作为原子化的、可共享的能力证书，可附加到多个角色并独立进化。

4. 设计了**双市场架构**（角色市场+执行者市场），形成组织增长的生态系统飞轮。

5. 提出了**五层记忆架构**，确保组织知识在执行者变更中持续存在。

6. 描述了**双轨进化机制**，将永久性角色进化（更新JD）与动态执行者适应（更新员工绩效评估）分离。

7. 通过**设计团队案例研究**展示了RAMS，包含24个角色和28+项技能，揭示了显著的复用和共享模式。

本文其余部分组织如下：第2节回顾相关工作；第3节详细介绍RAMS框架；第4节提供形式化定义；第5节描述实例化和案例研究；第6节讨论影响和局限性；第7节总结。

---

## 2. 相关工作

### 2.1 多智能体协作框架

基于LLM的多智能体系统领域自2023年以来快速发展。我们将现有方法分为三代。

**第一代：基于聊天的协作。** ChatDev（Qian et al., 2023）开创了多智能体软件开发的先河，通过模拟虚拟软件公司，智能体通过结构化聊天协议进行通信。智能体担任固定角色（CEO、CTO、程序员、测试员），遵循瀑布式开发流程。虽然具有创新性，但ChatDev将角色身份与执行紧密耦合——每个角色都是一个特定的智能体实例，没有岗位定义与执行者之间的分离。AgentVerse（Chen et al., 2023）通过更灵活的角色分配扩展了这一范式，但保持了单体智能体模型。

**第二代：编排框架。** AutoGen（Wu et al., 2023）引入了基于对话的灵活框架，智能体可以配置不同的系统提示和LLM后端。其关键创新是支持具有可定制角色的智能体间多轮对话。然而，AutoGen将角色视为字符串提示而非结构化的、独立管理的实体。MetaGPT（Hong et al., 2024）引入标准操作流程（SOP）作为组织智能体工作流的机制，代表向组织结构迈出的重要一步。MetaGPT定义了产品经理、架构师和工程师等角色，每个角色具有结构化输出。尽管如此，MetaGPT的角色仍然是单体的——它们在单个类定义中捆绑了人格、能力和执行。

CrewAI（Jones, 2024）采用任务导向的方法，定义具有角色、目标和背景故事的智能体，然后将它们分配到团队中的任务。虽然CrewAI的"角色"和"背景故事"概念表面上类似于RAMS的角色和灵魂，但它们嵌入在Agent类中，无法独立存储、复用或交易。LangGraph（LangChain AI, 2024）将范式从智能体中心转向工作流中心，将多智能体系统建模为有状态有向图。LangGraph擅长复杂控制流，但不提供角色管理、技能共享或市场动态的组织抽象。

**第三代：执行原生智能体。** OpenAI的Codex CLI（OpenAI, 2025）代表了向CLI原生智能体执行的转变，单个智能体在具有完整文件系统访问权限的沙箱环境中运行。oh-my-codex（2025）通过在Codex CLI之上添加多智能体协调的工作流层扩展了这一点。这些工具专注于执行效率而非组织结构，将智能体视为一次性执行器而非进化组织中的成员。

**生产级智能体框架。** oh-my-openagent（Kim, 2025）代表了迄今为止最成熟的多智能体编码系统的生产实现，在GitHub上拥有55.5k星标和超过220万次下载。它引入了11个专业化智能体——包括Sisyphus（一个负责规划、委派和验证的持久化编排器）、Hephaestus（一个自主深度工作者）和Prometheus（一个战略规划者）——通过基于类别的模型路由系统进行协调，将任务类型（ultrabrain、deep、quick、visual-engineering）映射到最优LLM后端。oh-my-openagent的架构无意中验证了几个RAMS概念：其Sisyphus编排器对应RAMS的编排器，其类别路由近似RAMS的执行者市场，其"智慧积累"机制预见了RAMS的角色进化。然而，oh-my-openagent缺乏四项关键的RAMS创新：（1）灵魂嵌入在智能体提示中，而非独立存储和可复用；（2）技能是任务级执行包（SKILL.md+嵌入式MCP服务器），而非具有N:M角色绑定的组织级能力证书；（3）没有用于发现、评估或交易角色和技能的市场机制；（4）进化是单维度的（跨任务学习），而非RAMS的双轨（角色进化+执行者适应）。我们在第6.4节提供了详细的映射。

**与RAMS的比较。** 表1总结了关键的架构差异。RAMS是第一个明确分离角色与智能体（执行者）、从角色中分解灵魂、实现N:M角色-技能绑定并提供双市场支持的框架。虽然现有框架已经孤立地引入了其中一些概念（例如MetaGPT的SOP近似组织流程），但没有一个提供了RAMS所提供的综合组织管理范式。

### 2.2 智能体技能表示

智能体能力的表示和管理日益受到关注。工具使用框架如Toolformer（Schick et al., 2023）、Gorilla（Patil et al., 2023）和API-Bank（Li et al., 2023）专注于教授LLM通过API调用调用外部工具。HuggingGPT（Shinn et al., 2023）通过允许LLM将多个Hugging Face模型编排为工具来扩展了这一点。

然而，这些方法将技能视为外部工具调用而非智能体的内在能力。在RAMS中，技能是**内在能力证书**，定义角色能做什么，而非能调用什么工具。RAMS中的技能类比于人类组织中的专业认证——它证明持有者具备特定能力，无论使用什么工具来行使该能力。

技能库的概念已在机器人学（Colas et al., 2020）和游戏AI（Baker et al., 2020）中得到探索，但这些领域的约束条件与基于LLM的智能体有显著不同。在LLM智能体领域，基于提示的技能定义（如ReAct（Yao et al., 2023）、Reflexion（Shinn et al., 2023））一直是主导范式，技能被编码为少样本示例或思维链模板。RAMS将技能从提示片段提升为具有独立生命周期管理的一级组织实体。

### 2.3 AI系统中的组织行为

将组织行为学原理应用于AI系统在多智能体系统研究中有着丰富的历史（Wooldridge and Jennings, 1995; Horling and Lesser, 2004）。早期关于组织自设计（Ishida et al., 1992）和自适应组织（Decker and Lesser, 1993）的工作为动态重构智能体组织奠定了理论基础。

在LLM时代，多项工作从人类组织中汲取灵感。ChatDev（Qian et al., 2023）明确模拟了软件公司结构。MetaGPT（Hong et al., 2024）借鉴了软件工程方法论。CAMEL（Li et al., 2023）使用角色扮演促进智能体协作。AgentTrek（2024）为复杂任务分解引入了组织层级。

然而，这些工作只是表面地应用了组织隐喻——它们使用组织角色名称（CEO、CTO、设计师），却没有实现使人类组织有效的深层组织机制：独立的职位描述、可迁移的专业身份、可共享的技能认证、基于绩效的适应和市场驱动的生态系统增长。RAMS是第一个将组织管理的核心抽象系统性地转化到AI智能体团队领域的框架。

"组织智能"（Malone and Crowston, 1994）的概念——即组织可以比其个体成员更聪明的理念——与RAMS尤为相关。RAMS通过其双轨进化机制实现了这一概念：角色进化积累的组织智能惠及所有当前和未来的执行者，而执行者适应优化个体性能而不修改组织知识。

---

## 3. RAMS框架

### 3.1 设计理念：从工具调用到组织管理

RAMS的根本设计理念是：**AI智能体团队应作为组织来管理，而非作为软件来编程**。这一理念体现在以下设计原则中：

**原则1：关注点分离。** 正如人类组织将岗位定义与填充岗位的人员分离，RAMS将*什么*（角色，定义需要做什么）与*谁*（执行者，定义谁来做）和*怎么做*（灵魂，定义行为风格）分离。

**原则2：复用优于重复。** 人类组织通过共享资源实现效率：岗位模板、专业认证、培训项目。RAMS通过使灵魂、技能和角色成为独立可复用实体来应用同一原则。

**原则3：在正确的层面进行进化。** 在人类组织中，改进职位描述惠及所有未来员工，而个人的绩效评估只影响该个人。RAMS的双轨进化将这一原则应用于AI智能体团队。

**原则4：市场驱动的生态系统。** 人类组织生态系统在劳动市场和职业网络的推动下蓬勃发展。RAMS的双市场架构为AI智能体团队创建了类似的经济机制。

**原则5：组织记忆。** 公司的知识在任何单个员工的任期之外持续存在。RAMS的五层记忆架构确保角色级记忆在执行者变更中存活，实现真正的组织学习。

### 3.2 核心概念：角色、灵魂、技能、执行者

RAMS定义了六个基础概念，每个概念都与人类组织结构有直接类比（见表2）。

**角色（ℛ）。** 角色是静态的岗位定义，类比于人类组织中的职位描述（JD）。形式化地，角色 ℛ = (Soul_ref, 𝕊skills, V, C)，其中Soul_ref是对独立灵魂实体的引用，𝕊skills是技能引用集合，V是角色变体集合（特定场景的岗位配置），C是角色的上下文和约束。角色以结构化文档（如`role.md`）存储，定义岗位的职责、所需能力和行为期望——而不指定*谁*来填充该岗位或*哪个*LLM来执行。

**灵魂（Σ）。** 灵魂是专业人格和工作风格定义，独立于任何角色存储。灵魂 Σ = (P, W, T)，其中P是专业个性（如严谨、创意、分析型），W是首选工作方式（如迭代式、系统式、探索式），T是沟通语气和风格。关键创新在于灵魂与角色是**正交**的：同一个灵魂可以被多个角色引用，一个角色可以切换其灵魂引用而不改变其功能定义。这类比于人类组织中一个人的职业风度在岗位变更中持续存在。灵魂以独立文档（如`soul.md`）存储，可以独立进行版本管理、交易和进化。

**技能（𝒦）。** 技能是原子化的专业能力证书，类比于人类组织中的专业认证。技能 𝒦 = (N, D, E, M)，其中N是技能名称，D是详细的能力描述，E是评估标准，M是技能级记忆（积累的最佳实践）。技能是RAMS中最小的独立可管理能力单元。

**执行者（𝒜）。** 执行者是特定的LLM模型实例，作为执行器，类比于人类组织中的特定人员（员工）。执行者 𝒜 = (Mmodel, Pparams, Hhistory)，其中Mmodel是底层模型（如GPT-5、Claude、Gemini），Pparams是模型参数和配置，Hhistory是执行者的历史性能数据。同一个执行者可以扮演不同的角色（正如一个人可以担任不同的工作），同一个角色可以由不同的执行者扮演（正如一个工作可以由不同的人填充）。

**角色实例（ℐ）。** 角色实例是角色到执行者的运行时绑定，类比于人类组织中的在职员工。角色实例 ℐ = (ℛ, 𝒜, 𝕄session, Ctx)，其中ℛ是活动角色，𝒜是分配的执行者，𝕄session是会话级记忆，Ctx是当前任务上下文。角色实例是临时的——它存在于任务持续期间，任务完成后即解散——而角色和执行者持续存在。

**编排器（Ω）。** 编排器是组织管理层，类比于公司管理层或项目经理。编排器Ω负责：（1）任务分解和角色分配，（2）执行者选择和调度，（3）角色间通信路由，（4）性能监控和进化触发，（5）市场交互。编排器本身不执行任务；它管理执行任务的组织。

### 3.3 角色-技能N:M绑定模型

RAMS最具意义的结构创新之一是角色与技能之间的N:M（多对多）绑定。在大多数现有框架中，能力要么单体嵌入在智能体定义中（1:1绑定），要么通过外部工具调用访问（无绑定）。RAMS引入了一个原则性的中间方案：技能是一级实体，可以通过显式绑定关系跨角色共享。

**定义。** 角色-技能绑定是一个二部图 G_RS = (ℛ ∪ 𝒦, E_RS)，其中 E_RS ⊆ ℛ x 𝒦 是绑定边集合。每条边 (r, k) ∈ E_RS 表示角色r需要技能k。

**性质。** N:M绑定模型展现了几项重要性质：

1. **技能共享。** 单个技能可以绑定到多个角色。例如，技能`design-state`（评估设计系统一致性的能力）可以被设计团队中的所有13个设计角色共享，确保团队内一致的评估标准。

2. **角色专业化。** 单个角色可以绑定多项技能，实现细粒度的能力规格。例如，`accessibility-reviewer`角色可以绑定30+项覆盖无障碍评估不同方面的专业化技能。

3. **增量能力。** 技能可以添加到角色或从角色移除，而不影响其他角色，实现增量式组织能力增长。

4. **技能级进化。** 当技能被更新时（例如基于积累的经验完善评估标准），绑定到该技能的所有角色自动受益于改进。

**类比。** 在人类组织中，N:M绑定对应于岗位和专业认证之间的关系。一个"项目经理"岗位可能同时要求"PMP认证"和"敏捷方法论认证"，而同一个"PMP认证"可以被许多不同的岗位（项目经理、项目群经理、项目组合经理）所要求。

### 3.4 灵魂-角色正交分解

灵魂与角色的正交分解是RAMS最具辨识度的架构特征。在所有现有多智能体框架中，行为人格嵌入在智能体定义中，使其与智能体的功能角色不可分离。RAMS通过干净的架构分离打破了这种耦合。

**正交性原理。** 灵魂和角色沿独立轴进化。形式化地，角色实例的能力空间 𝒞 是角色功能能力空间 𝒞ℛ 和灵魂行为调制空间 𝒞Σ 的笛卡尔积：

𝒞 = 𝒞ℛ x 𝒞Σ

这意味着改变角色的灵魂引用不会改变角色能做什么（其功能能力），只改变它怎么做（其行为风格）。反之，进化角色的能力不会影响可能附加到它的任何灵魂的行为风格。

**灵魂复用模式。** 灵魂的正交性实现了几种复用模式：

1. **跨角色灵魂共享。** 同一个灵魂可以被多个角色引用。例如，一个"严谨细致"的灵魂可以被代码审查者、设计评论家和无障碍审计员共享，确保不同评估角色间一致的细节关注度。

2. **灵魂切换。** 角色可以切换其灵魂引用以适应不同的项目上下文。例如，一个"内容撰写者"角色在头脑风暴阶段可能使用"创意探索型"灵魂，在文档阶段使用"精确简洁型"灵魂。

3. **独立灵魂进化。** 灵魂可以基于所有使用它的角色的反馈进行完善，创造一个行为改进惠及整个组织的良性循环。

4. **灵魂市场交易。** 由于灵魂是独立存储和版本管理的，它们可以发布到角色市场并从中获取，实现跨组织的有效行为模式共享。

**无现有等价物。** 据我们所知，现有任何多智能体框架都没有实现灵魂-角色正交分解。ChatDev和MetaGPT将人格嵌入在角色定义中。CrewAI的"背景故事"是Agent级属性。AutoGen的"系统消息"将功能指令与行为指导混在一起。RAMS是第一个将专业人格作为一级的、独立可管理的组织实体来处理的框架。

### 3.5 双轨机制：角色进化 vs 执行者适应

RAMS实现了用于组织改进的双轨机制，镜像了人类组织中"更新职位描述"和"更新员工绩效评估"之间的区别。

**轨道1：角色进化（永久性、组织级）。** 角色进化修改角色定义本身，影响所有当前和未来的角色实例，无论哪个执行者执行。该轨道包括：

- **技能积累。** 基于观察到的能力差距为角色添加新技能。
- **提示精炼。** 基于积累的最佳实践更新角色的核心提示。
- **变体创建。** 为特定场景创建新的角色变体。
- **记忆整合。** 将会话级学习提升为角色级记忆。

角色进化由编排器在观察到同一角色下多个执行者出现失败或次优性能模式时触发。它代表**组织学习**，在任何单次执行之外持续存在。

**轨道2：执行者适应（动态、调度级）。** 执行者适应修改执行者的调度和配置，而不改变任何角色定义。该轨道包括：

- **适配度评分。** 基于历史性能计算每个执行者-角色对的适配度分数。
- **动态调度。** 基于当前适配度分数和成本约束分配执行者到角色。
- **参数调优。** 为特定的执行者-角色组合调整模型参数（温度、top-p等）。
- **试演。** 测试新执行者对现有角色的适配性。

执行者适应在运行期间持续触发，仅影响调度层。它代表**个体性能优化**，不修改组织知识。

**对偶性原理。** 两条轨道互补且互不干扰：

角色进化 ⊥ 执行者适应

角色进化改进*组织*（任何执行者能达到的成就），执行者适应改进*分配*（哪个执行者最适合哪个角色）。这种分离确保组织改进不会因执行者更换而丢失，调度优化也不会破坏组织定义。

**类比。** 在人类公司中，角色进化对应于更新岗位的JD（例如为高级DevOps工程师JD添加"Kubernetes经验"），执行者适应对应于更新员工的绩效评估（例如记录Alice擅长事件响应但不擅长文档编写）。前者惠及所有未来入职者；后者只影响Alice的当前分配。

### 3.6 双市场架构

RAMS引入了双市场架构，为组织增长创建生态系统飞轮，类比于人类经济中的劳动力市场动态。

**角色市场（ℳℛ）。** 角色市场是发布、发现和获取角色定义的平台。它类比于人类组织中的招聘平台（如LinkedIn Jobs）。角色市场的参与者可以：

- **发布角色。** 上传角色定义（包括灵魂引用和技能绑定）供他人发现和使用。
- **发现角色。** 按能力需求、领域或与现有团队组成的兼容性搜索角色。
- **获取角色。** 下载并在自己的编排器中实例化已发布的角色。
- **评价角色。** 提供角色质量反馈，驱动声誉系统。
- **分叉和进化。** 基于现有角色创建衍生角色，为生态系统的多样性做出贡献。

**执行者市场（ℳ𝒜）。** 执行者市场是按需供给执行者实例的平台。它类比于人类组织中的外包或人才市场（如Upwork）。参与者可以：

- **注册执行者。** 提供具有特定配置和定价的LLM模型实例。
- **发现执行者。** 按模型类型、能力画像、成本和可用性搜索执行者。
- **请求试演。** 在正式使用前测试执行者对特定角色的适配性。
- **动态供给。** 根据需求扩展或缩减执行者容量。

**生态系统飞轮。** 两个市场创建了一个自我强化的循环：

1. 角色市场中更多的角色吸引更多用户加入生态系统。
2. 更多用户在执行者市场中产生更多执行者需求。
3. 更多执行者使更多的角色实验和验证成为可能。
4. 更好验证的角色吸引更多用户。

这种飞轮效应以封闭系统框架无法实现的方式驱动生态系统增长。

### 3.7 五层记忆架构

RAMS中的记忆组织为五个层次，全部在角色级别维护，以确保组织知识在执行者变更中持续存在。

**第1层：提示记忆（𝕄prompt）。** 定义角色核心行为的基础提示模板。该层最稳定，仅通过有意的角色进化来改变。

**第2层：会话档案（𝕄session）。** 过去任务执行的记录，包括输入、输出和结果。会话档案是组织学习的原始材料。

**第3层：技能记忆（𝕄skill）。** 技能级别积累的最佳实践和经验教训。当技能在多个角色间共享时，其技能记忆聚合所有使用角色的洞察，产生交叉授粉效应。

**第4层：向量索引（𝕄_vector）。** 索引角色积累知识的向量数据库，用于任务执行期间的高效检索。该层使角色实例能够快速访问相关的过往经验。

**第5层：用户画像（𝕄_user）。** 关于角色服务的用户的积累知识，包括偏好、沟通模式和质量期望。该层实现角色级别的个性化。

**记忆持久性属性。** 五层架构的一个关键属性是所有记忆层属于角色而非执行者。当执行者被替换时（例如从GPT-5切换到Claude），新执行者继承完整的记忆栈，确保组织知识的连续性。这类比于新员工接任一个岗位时获得该岗位的文档、程序和历史记录的访问权限。

**记忆流。** 在任务执行期间，记忆双向流动：角色实例从所有五个层读取以指导其行为，并将新经验写回第2-5层。编排器定期将有价值的从较低层的学习提升到较高层（例如，将成功的会话模式从第2层提升到第1层作为提示精炼）。

---

## 4. 形式化

### 4.1 角色-技能绑定形式化

我们将角色-技能绑定形式化为加权二部图，不仅捕获绑定的存在性，还捕获其强度和上下文。

**定义1（角色-技能绑定图）。** 设 ℛ = {r1, r2, ..., rm} 为角色集合，𝒦 = {k1, k2, ..., kn} 为技能集合。角色-技能绑定图为加权二部图 G_RS = (ℛ ∪ 𝒦, E_RS, w_RS)，其中：

- E_RS ⊆ ℛ x 𝒦 是绑定边集合
- w_RS: E_RS → (0, 1] 为每条边分配一个权重，表示技能对角色的重要性

**定义2（角色能力画像）。** 角色ri的能力画像定义为：

Φ(ri) = Σ w_RS(ri, kj) · φ(kj)  对所有 (ri, kj) ∈ E_RS

其中 φ(kj) 是技能kj的内在能力值，由其评估标准和积累的技能记忆决定。

**定义3（技能共享系数）。** 技能kj的共享系数衡量其组织影响力：

σ(kj) = |{ri ∈ ℛ : (ri, kj) ∈ E_RS}| / |ℛ|

σ(kj) = 1.0 的技能被所有角色共享（通用技能），σ(kj) ≈ 0 表示高度专业化的技能。

**定理1（通过共享的能力放大效应）。** 当共享技能kj被改进时（即 φ(kj) 增加），总组织能力增加量为：

ΔΦtotal = Δφ(kj) · Σ w_RS(ri, kj)  对所有 (ri, kj) ∈ E_RS

这种放大效应是N:M绑定模型的形式化依据：改进一个广泛共享的技能比改进同等数量的各绑定到单个角色的技能产生更大的组织收益。

### 4.2 灵魂加载优先级

当角色引用灵魂时，行为调制必须在不同执行者间一致地应用。我们形式化灵魂加载过程。

**定义4（灵魂加载函数）。** 给定具有灵魂引用Soul_ref的角色ℛ和执行者𝒜，灵魂加载函数产生有效行为配置：

Λ(ℛ, 𝒜) = Load(Soul_ref) o Adapt(Soul_ref, 𝒜)

其中 Load(Soul_ref) 检索灵魂的人格定义，Adapt(Soul_ref, 𝒜) 根据执行者的固有特征调整人格表达（例如不同的LLM可能自然表现出不同的沟通风格）。

**定义5（灵魂兼容度分数）。** 灵魂Σ与执行者𝒜之间的兼容度为：

ψ(Σ, 𝒜) = sim(Σ.style, 𝒜.baselinestyle) · cap(𝒜, Σ.requirements)

其中 sim(·, ·) 测量风格相似度，cap(·, ·) 测量执行者是否满足灵魂的最低能力要求。

### 4.3 执行者适配度评分

执行者适配度评分是更广泛的RAMS框架中的一个组件——具体来说，它属于执行者适应轨道（轨道2）。需要强调的是，评分是一种调度优化机制，而非RAMS的核心创新。

**定义6（执行者适配度分数）。** 在上下文C中执行者𝒜j对角色ℛi的适配度为：

Score(𝒜j, ℛi, C) = α · Perf(𝒜j, ℛi) + β · Cost(𝒜j)^(-1) + γ · Lat(𝒜j)^(-1) + δ · ψ(Σi, 𝒜j)

其中：

- Perf(𝒜j, ℛi) 是执行者j在角色i上的历史性能
- Cost(𝒜j) 是执行者j的每次请求成本
- Lat(𝒜j) 是执行者j的平均延迟
- ψ(Σi, 𝒜j) 是灵魂兼容度分数（定义5）
- α, β, γ, δ 是权重参数，α + β + γ + δ = 1

**定义7（最优分配）。** 给定一组角色实例 {ℐ1, ..., ℐn} 和执行者池 {𝒜1, ..., 𝒜m}，最优分配为：

argmax_{π ∈ Sn} Σ(i=1到n) Score(𝒜_π(i), ℛi, Ci)

受预算和延迟约束。这是分配问题的一个实例，可以使用匈牙利算法（Kuhn, 1955）在多项式时间内求解。

**范围说明。** 执行者适配度分数是RAMS众多组件之一。它服务于执行者适应轨道，与角色进化、灵魂管理、技能绑定或市场动态无关。RAMS的核心创新在于组织管理范式——角色与执行者的分离、灵魂的正交分解、N:M技能绑定和双市场——而非任何单一的评分公式。

### 4.4 角色进化动力学

我们将角色进化的动力学形式化为角色定义空间上的学习过程。

**定义8（角色状态）。** 角色ℛi在时间t的状态为：

ℛi(t) = (prompti(t), 𝕊skillsi(t), Vi(t), 𝕄i(t))

其中 prompti(t) 是当前提示模板，𝕊skillsi(t) 是当前技能集，Vi(t) 是当前变体集，𝕄i(t) 是当前记忆状态。

**定义9（角色进化算子）。** 角色ℛi从时间t到t+1的进化由以下公式控制：

ℛi(t+1) = ℛi(t) + Δprompt + Δskills + Δ_variants + Δmemory

其中每个Δ项代表来自进化触发器的积累变化：

- Δprompt = fprompt(𝕄session(t), feedback(t))：基于会话结果和用户反馈的提示精炼
- Δskills = fskills(gap_analysis(t))：基于能力差距分析的技能添加/移除
- Δ_variants = f_variants(scenario_data(t))：为观察到的使用场景创建新变体
- Δmemory = fmemory(𝕄session(t))：从会话到持久层的记忆整合

**定理2（单调改进性质）。** 在关于进化算子的合理假设下（具体而言，fprompt和fskills由成功的任务结果所驱动），角色的期望能力随时间非递减：

E[Φ(ℛi(t+1))] ≥ E[Φ(ℛi(t))]

这一性质确保角色进化驱动持续的组织改进，类比于管理良好的组织随时间积累制度知识。

---

## 5. 实例化与案例研究

### 5.1 设计团队实现

为验证RAMS框架，我们实现了一个设计团队，包含24个角色，组织为四个类别：

**设计角色（13个角色）。** 这些角色覆盖设计能力的完整光谱：
- 核心设计：`design-director`、`ui-designer`、`ux-designer`、`visual-designer`
- 专业设计：`motion-designer`、`illustrator`、`3d-designer`、`typographer`
- 评估：`design-critic`、`design-reviewer`、`design-system-auditor`
- 策略：`design-strategist`、`brand-designer`

**无障碍角色（4个角色）。** 专门用于无障碍评估的角色：
- `accessibility-reviewer`、`accessibility-auditor`、`wcag-compliance-checker`、`inclusive-design-specialist`

**AI角色（3个角色）。** 用于AI辅助设计的角色：
- `ai-design-assistant`、`ai-prompt-engineer`、`ai-output-evaluator`

**RAMS特定角色（4个角色）。** 用于组织管理的元级角色：
- `role-evolution-manager`、`skill-curator`、`soul-designer`、`orchestrator-assistant`

**技能（28+项技能）。** 设计团队使用28+项技能，包括：
- 共享技能：`design-state`、`using-designpowers`（被所有13个设计角色共享）
- 无障碍技能：30+项`accessibility-reviewer`专用的专业化技能
- 跨领域技能：`color-theory`、`typography-principles`、`layout-analysis`、`user-research`
- 元技能：`prompt-engineering`、`output-evaluation`、`self-reflection`

### 5.2 角色-技能矩阵分析

角色-技能绑定矩阵揭示了验证N:M绑定模型效用的显著结构模式。

**通用技能。** 两项技能——`design-state`和`using-designpowers`——绑定到所有13个设计角色（σ = 1.0）。这些技能定义了每个设计角色必须具备的基础设计系统意识。在单体框架中，这种共享能力将被复制13次；在RAMS中，它被定义一次并引用13次。

**高度专业化技能。** `accessibility-reviewer`角色绑定了30+项其他角色不使用的专用技能。这种极端专业化在没有N:M绑定的框架中是不切实际的，因为它需要在单个智能体的提示中嵌入30+项能力定义。在RAMS中，每项技能独立管理，使专业化变得可操作。

**技能共享集群。** 矩阵揭示了自然的技能共享集群：
- *设计评估集群*：`design-critic`、`design-reviewer`和`design-system-auditor`共享8项评估相关技能
- *视觉设计集群*：`visual-designer`、`illustrator`和`3d-designer`共享6项视觉构图技能
- *策略集群*：`design-director`、`design-strategist`和`brand-designer`共享5项战略分析技能

这些集群对应于设计组织内自然的"部门"，表明N:M绑定模型捕获了有意义的组织结构。

**定量分析。** 设 |E_RS| 表示角色-技能绑定的总数。在24个角色和28+项技能的情况下，最大可能绑定数（完全二部图）为24 x 28 = 672。实际绑定数约为180，产生绑定密度 ρ = 180/672 ≈ 0.27。这种稀疏但结构化的绑定模式是真实世界组织的特征，每个岗位只需要所有可用认证的一个聚焦子集。

每个角色的平均技能数为 k̄_R = 180/24 = 7.5，每个技能的平均角色数为 k̄_K = 180/28 ≈ 6.4。这些数字表明角色专业化（每个角色拥有可管理的技能数量）和技能复用（每项技能服务多个角色）之间的健康平衡。

### 5.3 灵魂复用模式

灵魂-角色正交分解实现了提供显著组织效率的复用模式。

**跨类别灵魂共享。** 几个灵魂跨角色类别共享：
- `meticulous-analyst`灵魂被`design-reviewer`、`accessibility-auditor`、`wcag-compliance-checker`和`ai-output-evaluator`使用——跨越设计、无障碍和AI类别
- `creative-explorer`灵魂被`ui-designer`、`illustrator`、`3d-designer`和`ai-prompt-engineer`使用
- `systematic-planner`灵魂被`design-director`、`design-strategist`、`role-evolution-manager`和`orchestrator-assistant`使用

**实践中的灵魂切换。** 在实现过程中，我们观察到`content-writer`角色（不在设计团队中，但在一个平行的内容团队中）根据任务阶段在三个灵魂之间切换：
- `creative-explorer`用于头脑风暴和创意构思
- `precise-technical`用于API文档
- `engaging-storyteller`用于营销文案

这种动态灵魂切换在人格嵌入在智能体定义中的框架中是不可能实现的。

**灵魂进化收益。** 当`meticulous-analyst`灵魂被完善以包含更多结构化的评估检查清单（基于来自`accessibility-auditor`角色的反馈）时，使用该灵魂的所有四个角色自动受益于改进。在单体框架中，同样的完善需要手动应用于四个独立的智能体定义。

---

## 6. 讨论

### 6.1 RAMS与现有范式的比较

RAMS代表了我们在思考AI智能体团队方式上的范式转变。表1总结了关键差异。

| 特性 | ChatDev | AutoGen | MetaGPT | CrewAI | LangGraph | Codex CLI | oh-my-openagent | **RAMS** |
|---|---|---|---|---|---|---|---|---|
| 角色 ≠ 智能体 | 否 | 否 | 否 | 部分 | 否 | 否 | 部分 | **是** |
| 灵魂独立 | 否 | 否 | 否 | 否 | 否 | 否 | 否 | **是** |
| N:M 角色-技能 | 否 | 否 | 否 | 否 | 否 | 否 | 否 | **是** |
| 双轨进化 | 否 | 否 | 部分 | 否 | 否 | 否 | 部分 | **是** |
| 双市场 | 否 | 否 | 否 | 否 | 否 | 否 | 否 | **是** |
| 角色级记忆 | 否 | 部分 | 部分 | 否 | 状态 | 否 | 部分 | **是（5层）** |
| 组织焦点 | 模拟 | 对话 | SOP | 任务 | 工作流 | 执行 | 执行 | **完整组织** |

*表1：多智能体框架间的特性比较。oh-my-openagent通过工程直觉部分实现了几个RAMS概念，但缺乏灵魂独立性、N:M技能绑定、市场动态和双轨进化的理论框架。*

根本区别在于现有框架在**智能体层面**运作（如何使单个智能体协同工作），而RAMS在**组织层面**运作（如何将智能体团队构建和管理为一个进化的组织）。这类似于通过向个人分配任务来管理小组项目与通过定义岗位、招聘流程、职业发展路径和组织文化来管理公司之间的区别。

### 6.2 与SSL表示的互补性

RAMS的组织管理范式与自监督学习（SSL）等表示学习方法（Devlin et al., 2019; He et al., 2020; Chen et al., 2020）是互补的而非竞争关系。SSL在模型层面运作，从数据中学习通用表示。RAMS在组织层面运作，结构化模型实例如何组织成团队。

具体而言，RAMS可以利用SSL预训练的模型作为其框架内的执行者。执行者适配度分数可以纳入基于SSL的能力评估。角色进化可以受益于SSL的表示质量——更好的表示带来更好的执行者性能，进而带来更准确的角色进化信号。

两种方法解决AI栈的不同层面：
- **SSL**：如何构建更好的个体模型（表示质量）
- **RAMS**：如何将模型组织成有效的团队（组织质量）

正如更好的个体员工有助于但不决定组织效能，更好的个体模型有助于但不决定多智能体团队效能。RAMS提供了将有能力个体模型转化为有效集体智慧的组织层。

### 6.3 局限性与未来工作

**角色-技能管理的可扩展性。** 随着角色和技能数量的增长，管理N:M绑定图变得越来越复杂。未来工作应探索自动化技能推荐系统，基于能力差距分析为角色推荐相关技能，类比于专业发展平台推荐认证。

**灵魂量化。** 目前，灵魂定义是定性的（基于文本的人格描述）。开发灵魂特征的量化度量将实现更精确的灵魂-角色匹配和更系统的灵魂进化。我们设想一个"灵魂嵌入"空间，相似的灵魂在其中聚集。

**市场治理。** 双市场引入了质量保证、知识产权和兼容性方面的挑战。未来工作应解决市场治理机制，包括角色认证标准、执行者基准测试协议和争议解决流程。

**实证验证。** 虽然我们的案例研究展示了RAMS的结构有效性，但需要大规模实证评估。我们计划进行对照实验，在标准化基准上比较RAMS组织的团队与单体智能体团队，测量任务质量、成本效率和组织学习率。

**跨领域泛化。** 我们当前的实例化聚焦于设计团队。未来工作应探索RAMS在软件工程、科学研究、法律分析和医疗健康等其他领域的适用性，不同领域可能需要不同的最优组织结构。

**与现有框架的集成。** RAMS被设计为可以与现有执行框架集成的组织管理层。未来工作应开发适配器，允许RAMS编排使用AutoGen、CrewAI或LangGraph构建的智能体，将RAMS的组织智能与这些框架的执行能力相结合。

### 6.4 RAMS作为生产系统的理论框架

oh-my-openagent的出现提供了令人信服的证据，表明RAMS的组织管理范式捕获了生产系统通过工程直觉独立发现的实际架构模式。表3将oh-my-openagent的具体实现映射到RAMS的理论概念。

| RAMS概念 | oh-my-openagent实现 | 覆盖度 |
|---|---|---|
| 编排器 | Sisyphus（4阶段：意图门控→代码库评估→智能委派→独立验证） | ~90% |
| 角色（专业化岗位） | 11个专业化智能体（Sisyphus、Hephaestus、Prometheus、Atlas、Oracle、Librarian、Explore、Metis、Momus、Multimodal-Looker、Sisyphus-Junior） | ~60%（无角色-执行者分离） |
| 执行者（模型后端） | 多模型支持（Claude、GPT、Gemini、MiniMax、Kimi） | ~100% |
| 执行者路由 | 类别系统（ultrabrain→GPT-5.4、deep→Codex、quick→Haiku、visual→Gemini） | ~70%（无评分、无市场） |
| 技能 | 嵌入式MCP技能（SKILL.md+每会话MCP服务器） | ~40%（任务级，非组织级） |
| 灵魂（独立人格） | 嵌入在智能体系统提示中 | 0%（非独立） |
| 角色-技能N:M绑定 | 技能是任务范围的，非角色范围的 | 0% |
| 角色市场 | 插件系统（无发现、评估或交易） | ~10% |
| 执行者市场 | 仅类别路由（无评分、无动态适应） | ~30% |
| 角色进化 | 智慧积累（跨任务学习迁移） | ~50%（单维度） |
| 执行者适应 | 无正式适配度评分 | 0% |
| 角色变体 | 无特定场景变体 | 0% |
| 记忆 | Boulder（会话连续性）+ Wisdom | ~40%（5层中的2层） |
| 并行执行 | 团队模式（最多8个智能体，git worktree隔离） | ~80% |
| 规划/执行分离 | Prometheus（规划）+ Atlas（执行）+ Metis（审查）+ Momus（审计） | ~90% |

*表3：oh-my-openagent实现到RAMS理论概念的映射。覆盖度基于概念对齐度估算，而非代码级功能对等度。*

这一分析揭示了一个关键洞察：oh-my-openagent仅凭工程直觉就实现了约60%的RAMS概念覆盖度，但缺失的40%——灵魂独立性、N:M技能绑定、市场动态和双轨进化——代表了RAMS提供的理论贡献。我们假设，明确采用RAMS的组织管理框架将允许oh-my-openagent（及类似系统）：（1）跨智能体复用灵魂而非复制人格定义，（2）将技能作为组织资产而非静态执行包进行进化，（3）通过市场机制开放生态系统增长，（4）将组织学习与个体模型适应分离。

此外，技能语义的根本差异值得强调。在oh-my-openagent中，技能回答"如何执行特定任务"（例如github-triage包含一个Python脚本和MCP服务器用于GitHub issue分类）。在RAMS中，技能回答"角色具备什么专业能力"（例如cognitive-accessibility证明角色能够评估认知负荷，无论使用什么工具）。这一区别将技能从一次性任务脚本转化为随时间积累价值的持久组织资产。

---

## 7. 结论

我们提出了RAMS（Role-Actor-Market System，角色-执行者-市场系统），一种面向AI智能体团队的综合组织管理范式。RAMS引入了六个基础概念——角色、灵魂、技能、执行者、角色实例和编排器——每个概念都与人类组织结构有直接类比，以及四项关键架构创新：角色-执行者分离、灵魂-角色正交分解、N:M角色-技能绑定和双市场架构。

RAMS的核心理念是：管理AI智能体团队从根本上是一个组织管理问题。正如人类组织发展了成熟的抽象概念来大规模管理人员团队，AI智能体团队也需要类似的抽象概念来管理LLM智能体团队。RAMS通过原则性的架构分解提供了这些抽象概念，实现复用、独立进化和生态系统增长。

我们包含24个角色和28+项技能的案例研究展示了RAMS框架的实际可行性，揭示了显著的灵魂复用和技能共享模式，验证了理论框架所承诺的组织效率提升。五层记忆架构确保了执行者变更间的组织连续性，双轨进化机制同时实现了组织学习和个体优化。

随着AI智能体变得越来越强大、多智能体系统变得越来越复杂，我们相信像RAMS这样的组织管理范式将成为构建可扩展、可进化且经济可持续的AI智能体生态系统的必备要素。AI的未来不仅是更好的模型——更是更好的组织。

---

## 参考文献

Baker, B., Kanitscheider, I., Markov, T., Wu, Y., Powell, G., McGrew, B., Mordatch, I., Morcos, A., Green, M., Schneideman, N., et al. (2020). Video game playing by deep reinforcement learning agents with human-like skills. *Nature*, 588(7839), 606--610.

Chen, T., Kornblith, S., Norouzi, M., and Hinton, G. (2020). A simple framework for contrastive learning of visual representations. In *Proceedings of the 37th International Conference on Machine Learning (ICML)*, pages 1597--1607.

Chen, W., Ma, X., Wang, X., and Cohen, W. (2023). Multi-agent collaboration: Harnessing the power of intelligent LLM agents. *arXiv preprint arXiv:2306.03314*.

Colas, C., Sigaud, O., and Oudeyer, P.-Y. (2020). GEP-PG: Decoupling exploration and exploitation in deep reinforcement learning algorithms. In *Proceedings of the 37th International Conference on Machine Learning (ICML)*, pages 2274--2284.

Decker, K. and Lesser, V. (1993). Designing a family of coordination algorithms. In *Proceedings of the First International Conference on Multi-Agent Systems (ICMAS)*, pages 73--80.

Devlin, J., Chang, M.-W., Lee, K., and Toutanova, K. (2019). BERT: Pre-training of deep bidirectional transformers for language understanding. In *Proceedings of the 2019 Conference of the North American Chapter of the Association for Computational Linguistics (NAACL-HLT)*, pages 4171--4186.

He, K., Chen, X., Xie, S., Li, Y., Dollár, P., and Girshick, R. (2020). Masked autoencoders are scalable vision learners. In *Proceedings of the IEEE/CVF Conference on Computer Vision and Pattern Recognition (CVPR)*, pages 16000--16009.

Hong, S., Zheng, X., Chen, J., Cheng, Y., Wang, Y., Zhang, Z., Wang, Z., Zhang, J., Zhou, D., and Chen, J. (2024). MetaGPT: Meta programming for a multi-agent collaborative framework. In *Proceedings of the International Conference on Learning Representations (ICLR)*.

Horling, B. and Lesser, V. (2004). A survey of multi-agent organizational paradigms. *The Knowledge Engineering Review*, 19(4), 281--316.

Ishida, T., Gasser, L., and Yokoo, M. (1992). Organization self-design of distributed production systems. *IEEE Transactions on Knowledge and Data Engineering*, 4(2), 123--134.

Jones, J. (2024). CrewAI: Framework for orchestrating role-playing autonomous AI agents. *GitHub repository*, https://github.com/joaomdmoura/crewAI.

Kuhn, H. W. (1955). The Hungarian method for the assignment problem. *Naval Research Logistics Quarterly*, 2(1-2), 83--97.

Kim, Y. (2025). oh-my-openagent: The strongest agent harness. GitHub repository. https://github.com/code-yeongyu/oh-my-openagent

[作者姓名在预印本中隐去]. (2025). From skill text to skill structure: The scheduling-structural-logical representation for agent skills. arXiv preprint arXiv:2604.24026v4.

LangChain AI. (2024). LangGraph: Stateful multi-agent orchestration. *Technical documentation*, https://langchain-ai.github.io/langgraph/.

Li, G., Hammoud, H. A. K. A., Itani, H., El-Kassas, W. S., and Gohary, N. M. (2023). Camel: Communicative agents for "mind" exploration of large language model society. *Advances in Neural Information Processing Systems*, 36.

Li, Y., Liang, N., Wang, S., Zhang, W., Chen, X., and Zhang, Y. (2023). API-Bank: A comprehensive benchmark for tool-augmented LLMs. *arXiv preprint arXiv:2304.08244*.

Malone, T. W. and Crowston, K. (1994). The interdisciplinary study of coordination. *ACM Computing Surveys*, 26(1), 87--119.

Mintzberg, H. (1979). *The Structuring of Organizations*. Prentice-Hall.

OpenAI. (2023). GPT-4 technical report. *arXiv preprint arXiv:2303.08774*.

OpenAI. (2025). Codex CLI: Coding agent for the command line. *Technical documentation*, https://github.com/openai/codex.

oh-my-codex. (2025). OmX: Oh My codeX workflow layer. *GitHub repository*, https://github.com/oh-my-codex/core.

Park, J. S., O'Brien, J. C., Cai, C. J., Morris, M. R., Liang, P., and Bernstein, M. S. (2023). Generative agents: Interactive simulacra of human behavior. In *Proceedings of the 36th Annual ACM Symposium on User Interface Software and Technology (UIST)*, pages 1--22.

Patil, S., Gonzalez, L., Zhang, T., Kalliamvakou, E., Perez, E., and Liang, P. (2023). Gorilla: Large language model connected with massive apis. *arXiv preprint arXiv:2305.15334*.

Qian, C., Cong, X., Yang, C., Chen, X., and Zhang, W. (2023). Communicative agents for software development. *arXiv preprint arXiv:2307.07924*.

Schick, T., Dwivedi-Yu, J., Dessi, R., Raileanu, R., Lomeli, M., Hambro, E., Casas, H., and Scialom, T. (2023). Toolformer: Language models can teach themselves to use tools. In *Advances in Neural Information Processing Systems*, 36.

Shinn, N., Cassano, F., Gopinath, A., Narasimhan, K., and Yao, S. (2023). Reflexion: Language agents with verbal reinforcement learning. *Advances in Neural Information Processing Systems*, 36.

Simon, H. A. (1947). *Administrative Behavior: A Study of Decision-Making Processes in Administrative Organization*. Macmillan.

Wang, L., Ma, C., Feng, X., Zhang, Z., Yang, H., Zhang, J., Chen, Z., Tang, J., Chen, Z., Lin, Y., et al. (2024). A survey on large language model based autonomous agents. *Frontiers of Computer Science*, 18(6), 186345.

Wooldridge, M. and Jennings, N. R. (1995). Intelligent agents: Theory and practice. *The Knowledge Engineering Review*, 10(2), 115--152.

Wu, Q., Bansal, G., Zhang, Y., Wu, S., Li, B., Wang, C., Zhang, S., Li, E., and Wang, C. (2023). AutoGen: Enabling next-gen LLM applications via multi-agent conversation. *arXiv preprint arXiv:2308.08155*.

Yao, S., Zhao, J., Yu, D., Du, N., Shafran, I., Narasimhan, K., and Cao, Y. (2023). ReAct: Synergizing reasoning and acting in language models. In *Proceedings of the International Conference on Learning Representations (ICLR)*.

---

## 附录A：人类组织映射

| 人类组织概念 | RAMS等价物 | 描述 |
|---|---|---|
| 公司/组织 | 编排器（Ω） | 顶层管理实体 |
| 招聘平台 | 角色市场（ℳℛ） | 发现和获取角色定义的平台 |
| 外包/人才市场 | 执行者市场（ℳ𝒜） | 按需执行者供给平台 |
| 职位描述（JD） | 角色（ℛ） | 静态岗位定义 |
| 专业人格 | 灵魂（Σ） | 独立存储的行为身份 |
| 专业证书 | 技能（𝒦） | 原子化能力认证 |
| 员工 | 角色实例（ℐ） | 角色+执行者的运行时绑定 |
| 具体人员 | 执行者（𝒜） | LLM模型实例 |
| 绩效评估 | 执行者适配度分数 | 执行者-角色适配度评估 |
| 岗位能力积累 | 角色进化 | 角色定义的永久性改进 |
| 培训/学习 | 任务后学习 | 从会话到持久层的记忆整合 |
| 项目经验 | 角色记忆 | 积累的组织知识 |
| 特定场景岗位 | 角色变体（V） | 专业化角色配置 |
| 人才A/B测试 | 角色试演 | 测试新执行者对角色的适配性 |

*表2：人类组织概念与RAMS等价物的完整映射。*

---

## 附录B：图示说明

**图1：RAMS架构概览。** 该图将完整的RAMS架构描绘为分层图。顶层显示编排器（Ω）作为中央管理实体。其下方，两条并行路径分支展开：角色路径（左）和执行者路径（右）。角色路径显示角色定义通过N:M绑定边连接到独立存储的灵魂实体和共享的技能实体。执行者路径显示不同的LLM模型（GPT-5、Claude、Gemini）作为执行者实例。底部，角色实例通过将角色连接到执行者形成，五层记忆架构附加到每个角色。两个市场框——角色市场和执行者市场——位于两侧，分别连接到角色路径和执行者路径。虚线箭头表示市场交互（发布、发现、获取）。双轨进化机制显示为两条平行水平箭头：一条标记"角色进化"（永久性，影响所有执行者），一条标记"执行者适应"（动态，仅影响调度）。

**图2：角色-技能N:M绑定矩阵。** 该图展示了设计团队案例研究中角色-技能绑定关系的二部图可视化。左侧，24个角色节点按四个颜色编码组排列：设计（蓝色，13个节点）、无障碍（绿色，4个节点）、AI（橙色，3个节点）和RAMS特定（紫色，4个节点）。右侧，28+个技能节点按类别排列。边将角色连接到其绑定的技能，边的粗细与绑定权重w_RS成正比。通用技能（design-state、using-designpowers）显示连接到所有13个设计角色的粗边。accessibility-reviewer节点显示连接到30+项专业化技能的密集边集群。三个虚线椭圆突出显示技能共享集群：设计评估、视觉设计和战略分析。图例指示颜色编码和边粗细比例尺。共享系数σ(kj)标注在选定的技能旁边。

---

## 附录C：形式符号汇总

| 符号 | 含义 |
|---|---|
| ℛ | 角色（岗位定义） |
| Σ | 灵魂（专业人格） |
| 𝒦 | 技能（能力证书） |
| 𝒜 | 执行者（LLM模型实例） |
| ℐ | 角色实例（角色+执行者绑定） |
| Ω | 编排器（组织管理） |
| ℳℛ | 角色市场 |
| ℳ𝒜 | 执行者市场 |
| G_RS | 角色-技能绑定二部图 |
| E_RS | 角色-技能绑定边 |
| w_RS | 绑定权重函数 |
| Φ(ri) | 角色能力画像 |
| σ(kj) | 技能共享系数 |
| Λ(ℛ, 𝒜) | 灵魂加载函数 |
| ψ(Σ, 𝒜) | 灵魂兼容度分数 |
| Score(𝒜j, ℛi, C) | 执行者适配度分数 |
| 𝕄prompt | 提示记忆（第1层） |
| 𝕄session | 会话档案（第2层） |
| 𝕄skill | 技能记忆（第3层） |
| 𝕄_vector | 向量索引（第4层） |
| 𝕄_user | 用户画像（第5层） |
| V | 角色变体 |

*表3：本文使用的形式符号汇总。*
