﻿# oh-my-openagent vs RAMS：深度对比分析

> oh-my-openagent 是 RAMS 在 coding 领域的"前理论实现"——它凭工程直觉触及了 RAMS 约 60% 的概念，但因为缺乏组织管理理论框架，缺失了 Soul 独立、N:M Skill 绑定、市场机制、双轨演化这四个 RAMS 的核心创新。

---

## 一、oh-my-openagent 概览

| 指标 | 数据 |
|------|------|
| GitHub Stars | 55.5k |
| 累计下载 | 2.2M+ |
| 月活下载 | 667.6k+ |
| Commits | 5,198 |
| 代码量 | 278k LOC (TypeScript) |
| Agent 数量 | 11 个 |
| Skill 数量 | 4 个内置 + 插件扩展 |
| 技术栈 | TypeScript + Bun + OpenCode |
| 许可证 | SUL (Source Use License) |
| 定位 | 最强 Agent Harness（执行引擎） |
| 领域 | 专注软件开发 |

---

## 二、核心架构对比

| 维度 | oh-my-openagent | RAMS |
|------|----------------|------|
| **定位** | Agent Harness（执行引擎） | 组织管理范式（Organization Paradigm） |
| **核心隐喻** | 神话人物团队（Sisyphus、Hephaestus、Prometheus...） | 人类组织（岗位、招聘、绩效、市场） |
| **Agent/Role 数量** | 11 个固定 Agent | 24+ 个可扩展 Role |
| **Skill 系统** | Skill-Embedded MCP（Skill 自带 MCP 服务器，按需启动） | N:M 绑定（Skill 是独立可交易的资产） |
| **模型路由** | Category System（ultrabrain/deep/quick/visual-engineering） | Actor Marketplace（动态适配评分） |
| **编排方式** | Sisyphus（主编排）→ 子 Agent 委派 | Orchestrator（组织管理层） |
| **记忆系统** | Boulder（会话恢复）+ Wisdom Accumulation | 五层记忆架构（Role 级） |
| **人格设定** | 每个 Agent 有固定人格（硬编码在 prompt 中） | Soul 独立存储，可跨 Role 复用 |
| **市场机制** | 无 | 双边市场（Role + Actor） |
| **进化机制** | Wisdom Accumulation（跨任务学习传递） | 双轨演化（Role 进化 + Actor 适配） |
| **领域** | 专注软件开发 | 通用（设计、开发、无障碍、AI...） |
| **技术栈** | TypeScript + Bun + OpenCode（已实现） | 尚未实现（框架阶段） |
| **术语体系** | Agent / Skill / Category / Harness | Role / Soul / Skill / Actor / Workforce |

---

## 三、逐层概念映射

| RAMS 概念 | oh-my-openagent 对应 | 实现程度 | 说明 |
|-----------|---------------------|---------|------|
| **Orchestrator（编排器）** | Sisyphus（永不眠的 CTO） | ✅ 完整 | 4 阶段：意图解析 → 代码库评估 → 智能委派 → 独立验证 |
| **Role（岗位）** | Agent（11 个专业 Agent） | ⚠️ 部分 | 有专业化分工，但 Role 与 Actor 未分离 |
| **Actor（执行者/模型）** | Model Backend | ✅ 完整 | Claude/GPT/Gemini/MiniMax/Kimi 多模型支持 |
| **Skill（技能）** | Skill（SKILL.md + Embedded MCP） | ⚠️ 含义不同 | 详见下文 Skill 对比 |
| **Actor 路由** | Category System | ✅ 完整 | ultrabrain→GPT-5.4, deep→Codex, quick→Haiku |
| **Role Instance（员工）** | Agent Session | ✅ 完整 | 会话级实例化 |
| **Soul（独立人格）** | ❌ 缺失 | ❌ | 人格嵌入在各 Agent prompt 中，不可复用 |
| **Role-Skill N:M** | ❌ 缺失 | ❌ | Skill 是任务级执行包，非组织级能力 |
| **Role Marketplace** | ❌ 缺失 | ❌ | 无市场机制 |
| **Actor Marketplace** | Category System | ⚠️ 30% | 仅有路由，无评分、无交易、无动态适配 |
| **Role Evolution** | Wisdom Accumulation | ⚠️ 单维度 | 跨任务学习传递，但无正式的 Role 定义进化 |
| **Actor Adaptation** | ❌ 缺失 | ❌ | 无正式的 Actor 适配评分机制 |
| **Role Variant** | ❌ 缺失 | ❌ | 无场景化变体 |
| **五层记忆** | Boulder + Wisdom | ⚠️ 两层 | 会话恢复 + 跨任务学习，缺向量索引、用户画像等 |
| **Team Mode（并行）** | Team Mode | ✅ 完整 | 最多 8 Agent 并行，支持 worktree 隔离 |
| **后置学习** | Wisdom Accumulation | ⚠️ 部分 | 有学习传递，但无自动提炼 Skill 的闭环 |

---

## 四、Skill 系统的本质区别（核心差异）

### 4.1 概念对比

| 维度 | oh-my-openagent 的 Skill | RAMS 的 Skill |
|------|------------------------|--------------|
| **本质** | 执行指令包（SKILL.md + MCP 服务器 + 脚本） | 专业能力证书（独立资产，可交易、可评分） |
| **绑定方式** | Skill 绑定到具体任务/Agent（按需注入） | Skill 通过 N:M 关系绑定到 Role |
| **生命周期** | 任务级（用完即毁，MCP 服务器按需启停） | 组织级（持久存在，跨任务、跨 Actor 积累） |
| **可复用性** | 同一 Skill 可在不同任务中使用 | 同一 Skill 可被多个 Role 共享，且共享进化 |
| **评分机制** | 无 | Task-Driven Scoring（skillId × taskType） |
| **市场交易** | 无 | Skill Marketplace |
| **进化能力** | 静态（SKILL.md 文件不变） | 动态（后置学习自动优化） |
| **类比** | 工具箱里的工具（锤子、螺丝刀） | 职业资格证书（PMP、CPA、CFA） |

### 4.2 一句话总结

> oh-my-openagent 的 Skill 是"怎么执行"（How），RAMS 的 Skill 是"具备什么能力"（What）。

### 4.3 具体例子

**oh-my-openagent 的 Skill 示例**：
- `github-triage`：自带 Python 脚本 `gh_fetch.py` + MCP 服务器，执行 GitHub Issue 自动分类
- `pre-publish-review`：发布前审查流程，包含具体检查步骤
- `hyperplan`：战略规划工具

**RAMS 的 Skill 示例**：
- `token-architecture`：设计令牌架构能力（被 design-lead、design-builder、design-critic 共享）
- `cognitive-accessibility`：认知无障碍评估能力（被 accessibility-reviewer、cognitive-accessibility-specialist 共享）
- `design-state`：设计状态管理能力（被全部 13 个设计类 Role 共享）

---

## 五、oh-my-openagent "做对了"的部分（与 RAMS 暗合）

### 5.1 编排器 + 专家委派

Sisyphus 不写代码，只做 4 件事：
1. **Intent Gate**：解析用户真实意图
2. **Codebase Assessment**：映射代码库架构
3. **Smart Delegation**：路由到正确的专家 Agent
4. **Independent Verification**：独立验证一切

这完全是 RAMS Orchestrator 的 coding 领域实现。

### 5.2 模型路由

| Category | 用途 | 默认模型 |
|----------|------|---------|
| `ultrabrain` | 硬逻辑、架构决策 | GPT-5.4 High |
| `deep` | 自主研究 + 执行 | GPT-5.3 Codex Medium |
| `quick` | 单文件修改 | Claude Haiku 4.5 |
| `visual-engineering` | 前端/UI/UX | Gemini 3.1 Pro |
| `artistry` | 创意性任务 | Gemini 3.1 Pro |
| `writing` | 文档/文案 | Kimi K2.5 |
| `git` | Git 操作 | Claude Haiku 4.5 |

这就是 RAMS Actor Marketplace 的简化版——基于任务类型自动选择最优模型。

### 5.3 规划与执行分离

- **Prometheus**（规划者）：访谈模式，探索代码库，创建详细执行计划。从不写代码。
- **Atlas**（执行者）：阅读已验证的计划，委派给专业 Agent。独立验证——从不相信子 Agent 的说法。
- **Metis**（计划顾问）：在计划中的歧义变成生产 Bug 之前捕获它们。
- **Momus**（计划审查者）：严苛验证，只有当计划无懈可击时才批准。

这映射到 RAMS 的 `design-strategist`（规划）→ `design-builder`（执行）→ `design-critic`（审查）分离。

### 5.4 专用 Agent（Role 专业化）

| Agent | 职责 | 模型 | RAMS 对应 |
|-------|------|------|-----------|
| Sisyphus | 主编排器 | Claude Opus 4.7 | agent-orchestrator |
| Hephaestus | 深度工作者 | GPT-5.4 | design-builder |
| Prometheus | 战略规划师 | Claude Opus 4.7 | design-strategist |
| Atlas | 主执行者 | Claude Sonnet 4.6 | design-lead |
| Oracle | 架构顾问 | GPT-5.4 High | (无直接对应) |
| Librarian | 文档搜索 | MiniMax M2.5 | design-scout |
| Explore | 代码搜索 | MiniMax M2.5 | design-scout |
| Metis | 计划顾问 | Claude Opus 4.7 | design-critic |
| Momus | 计划审查 | GPT-5.4 Extra High | heuristic-evaluator |

### 5.5 其他工程亮点

- **Hashline 编辑**：每行代码带内容哈希 `LINE#ID`，编辑前验证，零陈旧行错误
- **Boulder 会话恢复**：中断的工作从停下的地方精确恢复（`boulder.json`）
- **Skill-Embedded MCP**：Skill 自带 MCP 服务器，按需启动，用完即毁
- **Three-Tier MCP**：内置 MCP + Claude Code MCP + Skill-Embedded MCP
- **Team Mode**：最多 8 个 Agent 并行，支持 git worktree 隔离
- **Wisdom Accumulation**：每个任务的学习传递给后续所有任务

---

## 六、oh-my-openagent "没做到"的部分（RAMS 的独到之处）

### 6.1 Soul 没有独立

**oh-my-openagent**：Sisyphus 人格是"永不放弃的 CTO"，Hephaestus 是"执着的工匠"——这些人格硬编码在各自的 prompt 中，无法跨 Agent 复用。

**RAMS**：Soul 独立为 `soul.md`，可以被多个 Role 复用。比如"注重无障碍"这个 Soul 可以同时应用到 design-lead、content-writer、design-builder。

**后果**：
- oh-my-openagent 想让新 Agent 具备某种人格 → 从零写 prompt
- RAMS 想让新 Role 具备某种人格 → 引用已有 Soul

### 6.2 Skill 是"工具"而非"能力"

**oh-my-openagent**：Skill 是自包含的执行包（SKILL.md + MCP 服务器 + Python 脚本），本质是"怎么做某件事"。

**RAMS**：Skill 是组织级的能力声明，本质是"具备什么专业能力"。

**后果**：
- oh-my-openagent 的 github-triage Skill → 用完即毁，不会进化
- RAMS 的 cognitive-accessibility Skill → 随使用不断进化，所有使用它的 Role 自动受益

### 6.3 没有市场机制

**oh-my-openagent**：封闭系统——11 个 Agent、若干 Skill、4 个 Category 都是预定义的。用户可以安装插件，但没有市场机制来发现、评估、交易。

**RAMS**：双边市场——用户可以发布、交易、评价 Role 和 Skill，形成生态飞轮：
```
用户任务 → Skill 评分 → Role 自动组合 → 质量提升 → 更多用户 → 更多数据 → 更好的评分
```

### 6.4 演化只有单维度

**oh-my-openagent**：Wisdom Accumulation 是"每个任务的学习传递给后续所有任务"——单一维度的学习。

**RAMS**：双轨演化区分了两个独立维度：
- **Role Evolution（组织学习）**：改了岗位 JD，所有员工受益（永久性变化）
- **Actor Adaptation（个体适应）**：某个员工这次表现好，下次优先录用（动态变化）

### 6.5 没有 Role Variant

**oh-my-openagent**：每个 Agent 只有一个版本。

**RAMS**：Role 可以有多个变体（如 design-strategist 的 B2B/B2C/Mobile 变体），针对不同场景优化。

### 6.6 术语体系面向开发者

**oh-my-openagent**：使用 Agent、Harness、Category、Skill 等技术术语，面向开发者。

**RAMS**：使用 Role、Soul、Actor、Workforce 等组织术语，面向非技术用户（设计师、产品经理、企业主）。

---

## 七、RAMS 应该从 oh-my-openagent 学习什么

| oh-my-openagent 的优势 | RAMS 应该借鉴 | 优先级 |
|----------------------|---------------|--------|
| 生产级工程质量（278k LOC, 5198 commits） | 实现时注重工程规范、模块化 | P0 |
| Category 路由（基于意图自动选模型） | Actor Marketplace 的智能调度算法 | P0 |
| Skill-Embedded MCP（Skill 自带工具） | Skill 的 How 层实现方式 | P1 |
| Hashline 编辑（内容哈希验证） | 实现层的工程最佳实践 | P1 |
| Boulder 会话恢复（中断后精确恢复） | Role Instance 的状态管理 | P1 |
| Team Mode（并行多 Agent） | Orchestrator 的并行执行引擎 | P0 |
| Wisdom Accumulation（跨任务学习） | Role Evolution 的数据来源 | P1 |
| IntentGate（意图解析） | Orchestrator 的任务理解层 | P1 |
| 规划/执行分离（Prometheus/Atlas） | Orchestrator 的两阶段执行 | P0 |
| 独立验证（Trust But Verify） | 评分系统的自动校验 | P1 |

---

## 八、差异化定位总结

```
oh-my-openagent = 最强的 Agent 执行引擎（怎么干）
RAMS              = 最完整的 AI 组织管理范式（谁来干、干什么、怎么评、怎么进化）
```

| 维度 | oh-my-openagent | RAMS |
|------|----------------|------|
| 核心问题 | 如何让 AI 更好地写代码？ | 如何像管理人类团队一样管理 AI 团队？ |
| 用户群体 | 开发者 | 所有人（设计师、产品经理、企业主...） |
| 领域范围 | 软件开发 | 通用（任何领域） |
| Skill 含义 | 执行工具 | 能力资产 |
| 人格管理 | 硬编码 | 独立复用 |
| 市场生态 | 封闭系统 | 双边市场 |
| 进化方式 | 单维度学习 | 双轨演化 |
| 理论基础 | 工程直觉 | 组织管理理论 |

---

## 九、结论

oh-my-openagent 已经证明了"AI 虚拟开发团队"的巨大市场价值（55.5k stars, 2.2M+ 下载）。它的成功说明：

1. **多 Agent 协作是刚需**，不是伪需求
2. **模型路由是核心能力**，不同任务需要不同模型
3. **规划与执行分离**是正确的设计模式
4. **专业化的 Agent** 比万能 Agent 更有效

RAMS 要做的是将 oh-my-openagent 验证过的工程实践**抽象为通用理论框架**，使其可以从 coding 扩展到设计、无障碍、内容、研究等任何领域——让任何领域都能像组建人类团队一样组建 AI 团队。

**oh-my-openagent 是 RAMS 在 coding 领域的最佳参考实现，但 RAMS 的理论框架提供了它缺失的 Soul 独立、N:M Skill 绑定、市场机制、双轨演化四个核心创新。**