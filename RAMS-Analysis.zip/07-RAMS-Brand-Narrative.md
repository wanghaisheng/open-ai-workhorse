﻿# RAMS 鍝佺墝鍙欎簨绛栫暐

---

## 涓€銆佷笁灞傚彊浜嬫灦鏋?
RAMS 闈㈠悜涓嶅悓鐢ㄦ埛缇や綋锛岄噰鐢ㄤ笁灞傚彊浜嬬瓥鐣ワ細

### 1.1 鐢叉柟鍙欎簨锛圕lient Narrative锛夆€?闈㈠悜鏈€缁堢敤鎴?
> **"You own the product. RAMS owns the team."**
>
> 浣犲彧绠℃彁闇€姹傦紝RAMS 鏇夸綘缁勫缓鍜岀鐞?AI 璁捐鍥㈤槦銆?
**鏍稿績淇℃伅**锛?- 鐢ㄦ埛涓嶉渶瑕佺悊瑙?Role/Skill/Actor 鐨勬妧鏈粏鑺?- 鐢ㄦ埛鍙渶瑕侊細鎻忚堪闇€姹?鈫?鑾峰緱楂樿川閲忚緭鍑?- RAMS 鍍忎竴涓?AI 鍥㈤槦缁忕邯浜?

**瀵规瘮褰撳墠涓绘祦妗嗘灦**锛?| 涓绘祦妗嗘灦 | RAMS |
|----------|------|
| DEFINE 鈫?PLAN 鈫?BUILD 鈫?VERIFY 鈫?REVIEW 鈫?SHIP | 鎻忚堪闇€姹?鈫?鑾峰緱浜や粯 |
| 鐢ㄦ埛绠＄悊姣忎釜闃舵 | RAMS 鑷姩缂栨帓 |
| 鐢ㄦ埛鍏冲績"鎬庝箞鍋? | 鐢ㄦ埛鍙叧蹇?鍋氫粈涔?鍜?濂戒笉濂? |

### 1.2 鍥㈤槦鍙欎簨锛圱eam Narrative锛夆€?闈㈠悜鎶€鏈敤鎴?
> **"Recruit AI teams for your design tasks. Leverage RAMS to treat AI and LLM providers as your AI workforce."**
>
> 涓轰綘鐨勮璁′换鍔℃嫑鍕?AI 鍥㈤槦銆傜敤 RAMS 鎶?AI 鍜?LLM 渚涘簲鍟嗗綋浣滀綘鐨?AI 鍛樺伐銆?
**鏍稿績淇℃伅**锛?- RAMS = AI 鍥㈤槦绠＄悊骞冲彴
- 姣忎釜 Role = 涓€涓?AI 鍥㈤槦鎴愬憳
- 姣忎釜 Skill = 涓€椤逛笓涓氭妧鑳?- 姣忎釜 Actor = 涓€涓叿浣撶殑 AI 宸ヤ汉锛堟ā鍨?+ 渚涘簲鍟嗭級

**鍥㈤槦闅愬柣**锛?```
鈹屸攢鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹?鈹?          RAMS AI Design Team            鈹?鈹?                                        鈹?鈹? 鈹屸攢鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹? 鈹屸攢鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹?            鈹?鈹? 鈹侱esign    鈹? 鈹侱esign    鈹?            鈹?鈹? 鈹係trategist鈹? 鈹侺ead      鈹?            鈹?鈹? 鈹?绛栫暐甯?  鈹? 鈹?璐熻矗浜?  鈹?            鈹?鈹? 鈹斺攢鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹? 鈹斺攢鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹?            鈹?鈹?                                        鈹?鈹? 鈹屸攢鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹? 鈹屸攢鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹?            鈹?鈹? 鈹侱esign    鈹? 鈹侱esign    鈹?            鈹?鈹? 鈹侭uilder   鈹? 鈹侰ritic    鈹?            鈹?鈹? 鈹?鏋勫缓鑰?  鈹? 鈹?璇勫鑰?  鈹?            鈹?鈹? 鈹斺攢鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹? 鈹斺攢鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹?            鈹?鈹?                                        鈹?鈹? 鈹屸攢鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹? 鈹屸攢鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹?            鈹?鈹? 鈹侰ontent   鈹? 鈹侻otion    鈹?            鈹?鈹? 鈹俉riter    鈹? 鈹侱esigner  鈹?            鈹?鈹? 鈹?鏂囨)    鈹? 鈹?鍔ㄦ晥)    鈹?            鈹?鈹? 鈹斺攢鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹? 鈹斺攢鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹?            鈹?鈹斺攢鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹?```

### 1.3 绯荤粺鍙欎簨锛圫ystem Narrative锛夆€?闈㈠悜寮€鍙戣€?璐＄尞鑰?
> **"RAMS: Role/Actor/Model/Skill 鈥?The Kubernetes for AI Agent Teams"**
>
> RAMS 鏄?AI Agent 鍥㈤槦鐨?Kubernetes銆?
**鏍稿績淇℃伅**锛?- RAMS = 澹版槑寮?AI 鍥㈤槦缂栨帓绯荤粺
- Role = Pod 瀹氫箟锛堝０鏄庡紡锛?- Actor = Node/Container锛堣繍琛屾椂缁戝畾锛?- Skill = Container Image锛堝彲澶嶇敤鑳藉姏鍗曞厓锛?- Marketplace = Container Registry锛堣兘鍔涘垎鍙戯級
- Scoring = Monitoring + SLO锛堣川閲忎繚闅滐級

---

## 浜屻€丼logan 婕旇繘

### V1锛堢洿璇戯級
> RAMS: Role/Actor/Model/Skill framework for AI-powered design

### V2锛堝洟闃熷彊浜嬶級
> Recruit AI teams for your design tasks. Leverage RAMS in AI design, treat AI and LLM providers as AI workforce.

### V3锛堢敳鏂瑰彊浜嬶級
> You own the product. RAMS owns the team.

### V4锛堢郴缁熷彊浜嬶級
> RAMS: The Kubernetes for AI Agent Teams.

### V5锛圖esign 棰嗗煙涓撶簿锛?> Design at the speed of thought. RAMS assembles your AI design team in seconds.

---

## 涓夈€佸彊浜嬩娇鐢ㄥ満鏅?
| 鍦烘櫙 | 鎺ㄨ崘鍙欎簨 | Slogan |
|------|---------|--------|
| GitHub README 棣栧睆 | 绯荤粺鍙欎簨 | V4 |
| 浜у搧瀹樼綉 Hero | 鐢叉柟鍙欎簨 | V3 |
| 鎶€鏈崥瀹?| 鍥㈤槦鍙欎簨 | V2 |
| 寮€鍙戣€呮枃妗?| 绯荤粺鍙欎簨 | V4 |
| 绀句氦濯掍綋浼犳挱 | 鐢叉柟鍙欎簨 | V3 |
| 鎶曡祫浜?Pitch | 鐢叉柟鍙欎簨 + 绯荤粺鍙欎簨 | V3 + V4 |
| Design 绀惧尯鎺ㄥ箍 | 鐢叉柟鍙欎簨 | V5 |

---

## 鍥涖€佷笌绔炲搧鍙欎簨鐨勫樊寮傚寲

| 绔炲搧 | 鍙欎簨瑙掑害 | RAMS 鐨勫樊寮傚寲 |
|------|---------|-------------|
| agent-skills | "Better prompts" | RAMS: "Better team, not just better prompts" |
| oh-my-agent | "Multi-agent harness" | RAMS: "Team orchestration with scoring" |
| oh-my-codex | "Codex supercharger" | RAMS: "Engine-agnostic team platform" |
| Hermes/OpenClaw | "Your AI assistant" | RAMS: "Your AI team" |
| Cursor/Claude Code | "AI coding tool" | RAMS: "AI team management platform" |

**鏍稿績宸紓璇?*锛?- 浠栦滑璇?"agent" 鈫?鎴戜滑璇?"team"
- 浠栦滑璇?"skill" 鈫?鎴戜滑璇?"workforce capability"
- 浠栦滑璇?"workflow" 鈫?鎴戜滑璇?"team collaboration"
- 浠栦滑璇?"execute" 鈫?鎴戜滑璇?"deliver"
