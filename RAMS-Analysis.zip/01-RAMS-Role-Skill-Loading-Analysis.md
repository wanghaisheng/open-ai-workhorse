﻿# RAMS Design Team — Role-Skill 加载机制与竞品分析

> 基于 open-design-rams 现有 .claude/roles/ + .claude/skills/ 分析，参考 oh-my-agent 架构，设计 RAMS 的 Role 默认 Skill 加载机制、Local Marketplace 模式及竞品差异化策略。

---

## 一、现有资产盘点

### 1.1 Role 清单（16 个）

| 分类 | Role | 描述 | 技能数量 |
|------|------|------|----------|
| **核心设计** | design-lead | 视觉设计执行专家 | 11 (P0:3, P1:3, P2:5) |
| | design-builder | 原型和实现专家 | 10 (P0:3, P1:3, P2:4) |
| | design-critic | 设计评审专家 | 8 (P0:4, P1:3, P2:1) |
| | design-strategist | 上游设计思维专家 | 8 (P0:3, P1:3, P2:2) |
| | design-scout | 竞争UX分析专家 | 5 (P0:2, P1:2, P2:1) |
| | content-writer | UX写作专家 | 5 (P0:2, P1:2, P2:1) |
| | inspiration-scout | 美学灵感专家 | 3 (P0:2, P1:1, P2:0) |
| | motion-designer | 动效设计专家 | 3 (P0:2, P1:1, P2:0) |
| | heuristic-evaluator | 启发式评估专家 | 3 (P0:2, P1:1, P2:0) |
| **无障碍专项** | accessibility-reviewer | 无障碍评审专家 | 30+ (最丰富) |
| | inclusive-researcher | 包容性研究员 | 8 |
| | adaptive-interface-specialist | 自适应界面专家 | 10 |
| | cognitive-accessibility-specialist | 认知无障碍专家 | 10 |
| **AI 专项** | agent-orchestrator | 智能体编排者 | 7 |
| | ai-personality-designer | AI个性设计师 | 7 |
| | model-evaluation-specialist | 模型评估专家 | 7 |

### 1.2 Skill 资产（1 个复合 Skill）

当前仅 .claude/skills/designer-role/ 一个 Skill 目录，内部包含 30+ 子技能模块，覆盖 9 大职责领域。

### 1.3 现有架构问题

| 问题 | 描述 |
|------|------|
| Role 内嵌 Skill | Skill 以字符串 ID 写在 role.md 中，无独立定义文件 |
| Skill 无独立定义 | 30+ 子技能散落，无结构化元数据 |
| 无加载优先级机制 | config.yaml 只有 auto_load: true |
| 无评分系统 | 无 Skill 效果评估和用户反馈机制 |
| IDE 绑定 | .claude/roles 硬绑定 Claude IDE |

---

## 二、oh-my-agent 参考架构

### 2.1 核心模式：Agent-Skill 两层分离

.agents/ 作为 SSOT，agents/ 存放轻量 Agent prompt，skills/ 存放深度知识库，_shared/ 存放共享协议。

### 2.2 局限与 RAMS 机会

| oh-my-agent 局限 | RAMS 差异化 |
|------------------|-------------|
| Agent-Skill 1:1 绑定 | N:M 多对多 |
| 无评分系统 | task-driven scoring |
| 无 Marketplace | dual Marketplace |
| Skill 无任务类型标注 | skillId x taskType 矩阵 |

---

## 三、RAMS 三层加载机制

Layer 3: Marketplace (最高优先) > Layer 2: User Custom > Layer 1: Default (基线)
合并策略：同名 Skill，高层覆盖低层

### 3.1 Default Skills 声明格式

```yaml
version: "1.0"
role: design-lead
default_skills:
  - skill_id: token-architecture
    priority: P0
    required: true
  - skill_id: design-taste
    priority: P2
    default_enabled: false
```

### 3.2 Skill 元数据格式

```yaml
id: token-architecture
name: 设计令牌架构
version: "1.0.0"
task_types:
  - design-system: { weight: 0.95 }
  - visual-design: { weight: 0.85 }
default_score: 7.5
dependencies: []
tags: [设计系统, 令牌, 颜色, 排版]
```

---

## 四、现有 Role 到 RAMS Skill 映射

### design-lead
P0: token-architecture, design-system-alignment, ui-composition
P1: design-state, responsive-patterns, interaction-design
P2: design-taste, adaptive-interfaces

### accessibility-reviewer (最丰富，30+ Skills)
P0 内容无障碍: alt-text-design, form-labelling, heading-structure 等 7 个
P0 交互无障碍: keyboard-navigation, touch-target-design 等 7 个
P1 无障碍策略: accessibility-testing-strategy, compliance-mapping 等 6 个

### agent-orchestrator
P0: agent-role-design, handoff-protocols, human-in-the-loop, failure-recovery, observability-design, state-management, task-decomposition

---

## 五、Local Marketplace 评分

评分公式：综合评分 = 自动评估分 x 0.6 + 用户反馈分 x 0.4
查询优先级：个人+任务类型 > 个人整体 > 默认评分(7.0)
升级路径：Local 个人评分 → Marketplace 聚合评分（数据结构一致，切换数据源即可）

---

## 六、竞品差异化

| 维度 | oh-my-agent | agent-skills | Hermes | claw-code | RAMS |
|------|-------------|--------------|--------|-----------|------|
| 定位 | 多Agent框架 | Skill合集 | 通用助手 | Code运行时 | 团队编排 |
| Role-Skill | 1:1 | 无 | 无 | 无 | N:M |
| Skill评分 | 无 | stars | 无 | 无 | task-driven |
| Marketplace | APM | GitHub | 无 | 无 | dual |
| 领域专精 | 软件工程 | 通用 | 通用 | 编码 | 设计+可扩展 |

---

## 七、核心设计决策

1. Skill 从 Role 解耦，100+ Skill ID 拆分为独立模块
2. 3 层加载优先级，用户始终拥有最终控制权
3. task-driven 评分，同一 Skill 在不同任务类型中独立评分
4. Local 优先，Marketplace 上线后无缝升级
5. 参考不复制 oh-my-agent，加入评分系统和 Marketplace
